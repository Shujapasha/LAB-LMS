<?php ($modules = App\Models\Module::cacheFor(now()->addDays())->toBase()->get()); ?>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('dashboard*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('dashboard*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('dashboard')); ?>">
            <span class="menu-title"><?php echo e(__('messages.dashboard.dashboard')); ?></span>
        </a>
    </div>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('users*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('users*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('users.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.users')); ?></span>
        </a>
    </div>
    <?php endif; ?>
</div>


<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('my-transactions*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('my-transactions*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('subscriptions.plans.transactions.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.subscription_plans.transactions')); ?></span>
        </a>
    </div>
</div>

<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('subscription-plans*') && !Request::is('choose-payment-type*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('subscription-plans*') || Request::is('choose-payment-type*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('subscription.pricing.plans.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.subscription_plans.subscription_plans')); ?></span>
        </a>
    </div>
    <?php endif; ?>
</div>

<div
        class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('ipds*','opds*')) ? 'd-none' : ''); ?>"
        id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'IPD Patients',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('ipds*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('ipd.patient.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.ipd_patients')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'OPD Patients',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('opds*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('opd.patient.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.opd_patients')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('vaccinated-patients*','vaccinations*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Vaccinated Patients',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('vaccinated-patients*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('vaccinated-patients.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.vaccinated_patients')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Vaccinations',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('vaccinations*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('vaccinations.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.vaccinations')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('accounts*','employee-payrolls*','invoices*','payments*','payment-reports*','advanced-payments*','bills*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Accounts',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('accounts*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('accounts.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.accounts')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Employee Payrolls',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee-payrolls*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('employee-payrolls.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.employee_payrolls')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Invoices',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('invoices*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('invoices.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.invoices')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Payments',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('payments*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('payments.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.payments')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Payment Reports',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('payment-reports*') ? 'show' : ''); ?>">
        <a class="menu-link py-3" href="<?php echo e(route('payment.reports')); ?>">
            <span class="menu-title"><?php echo e(__('messages.payment.payment_reports')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Advance Payments',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('advanced-payments*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('advanced-payments.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.advanced_payments')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Bills',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('bills*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('bills.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.bills')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('bed-types*','beds*','bed-assigns*','bulk-beds','bed-status')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Nurse')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Bed Types',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('bed-types*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('bed-types.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.bed_types')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Nurse')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Beds',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e((Request::is('beds*') || Request::is('bulk-beds')) ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('beds.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.beds')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Nurse|Doctor')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Bed Assigns',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('bed-assigns*','bed-status') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('bed-assigns.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.bed_assigns')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('blood-banks*','blood-donors*','blood-donations*','blood-issues*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Blood Banks',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('blood-banks*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('blood-banks.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.blood_banks')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Blood Donors',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('blood-donors*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('blood-donors.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.blood_donors')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Blood Donations',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('blood-donations*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('blood-donations.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.blood_donations')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Blood Issues',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('blood-issues*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('blood-issues.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.blood_issues')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('patients*','patient-cases*','case-handlers*','patient-admissions*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Patients',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patients*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('patients.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.patients')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist|Case Manager')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Cases',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patient-cases*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('patient-cases.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.cases')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Case Handlers',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('case-handlers*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('case-handlers.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.case_handlers')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist|Doctor|Case Manager')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Patient Admissions',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patient-admissions*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('patient-admissions.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.patient_admissions')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/doctor*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Case Manager|Pharmacist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/doctor*') ? 'show' : ''); ?>">
        <a class="menu-link py-3" href="<?php echo e(url('employee/doctor')); ?>">
            <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('documents*','document-types*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor|Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Documents',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('documents*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('documents.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.documents')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Document Types',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('document-types*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('document-types.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.document_types')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('insurances*','packages*','services*','ambulances*','ambulance-calls*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Insurances',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('insurances*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('insurances.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.insurances')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Packages',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('packages*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('packages.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.packages')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Services',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('services*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('services.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.services')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist|Case Manager')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Ambulances',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('ambulances*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('ambulances.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.ambulances')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist|Case Manager')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Ambulances Calls',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('ambulance-calls*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('ambulance-calls.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.ambulance_calls')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('doctors*','doctor-departments*','schedules*','prescriptions*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('doctors*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('doctors.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctor Departments',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('doctor-departments*') ? 'show' : ''); ?>">
        <?php
        $style = 'style=';
        $background = 'white-space:';
        ?>
        <a class="menu-link py-3"
           href="<?php echo e(route('doctor-departments.index')); ?>">
            <span class="menu-title" <?php echo e($style); ?>"<?php echo e($background); ?>nowrap"><?php echo e(__('messages.doctor_departments')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctor Designations',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('doctor-designations*') ? 'show' : ''); ?>">
        <?php
        $style = 'style=';
        $background = 'white-space:';
        ?>
        <a class="menu-link py-3"
           href="<?php echo e(route('doctor-designations.index')); ?>">
            <span class="menu-title" <?php echo e($style); ?>"<?php echo e($background); ?>nowrap"><?php echo e(__('messages.doctor_designations')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctor Categories',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('doctor-categories*') ? 'show' : ''); ?>">
        <?php
        $style = 'style=';
        $background = 'white-space:';
        ?>
        <a class="menu-link py-3"
           href="<?php echo e(route('doctor-categories.index')); ?>">
            <span class="menu-title" <?php echo e($style); ?>"<?php echo e($background); ?>nowrap"><?php echo e(__('messages.doctor_categories')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Schedules',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('schedules*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('schedules.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.schedules')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Prescriptions',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('prescriptions*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('prescriptions.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.prescriptions')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('accountants*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Accountants',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('accountants*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('accountants.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.accountants')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('nurses*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Nurses',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('nurses*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('nurses.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.nurses')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('receptionists*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Receptionists',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('receptionists*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('receptionists.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.receptionists')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('lab-technicians*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Lab Technicians',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('lab-technicians*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('lab-technicians.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.lab_technicians')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('pharmacists*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Pharmacists',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('pharmacists*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('pharmacists.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.pharmacists')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('appointments*','appointment-calendars')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Appointments',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('appointments*','appointment-calendars') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('appointments.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.appointments')); ?></span>
        </a>
    </div>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('birth-reports*','death-reports*','investigation-reports*','operation-reports*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Birth Reports',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('birth-reports*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('birth-reports.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.birth_reports')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Death Reports',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('death-reports*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('death-reports.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.death_reports')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Investigation Reports',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('investigation-reports*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('investigation-reports.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.investigation_reports')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Operation Reports',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('operation-reports*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('operation-reports.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.operation_reports')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('categories*','brands*','medicines*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Pharmacist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Medicine Categories',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('categories*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('categories.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.medicine_categories')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Pharmacist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Medicine Brands',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('brands*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('brands.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.medicine_brands')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Pharmacist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Medicines',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('medicines*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('medicines.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.medicines')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('radiology-categories*','radiology-tests*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Radiology Categories',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('radiology-categories*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('radiology.category.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.radiology_category.radiology_categories')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist|Pharmacist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Radiology Tests',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('radiology-tests*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('radiology.test.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.radiology_tests')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('pathology-categories*','pathology-tests*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Pathology Categories',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('pathology-categories*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('pathology.category.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.pathology_category.pathology_categories')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist|Pharmacist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Pathology Tests',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('pathology-tests*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('pathology.test.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.pathology_tests')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('diagnosis-categories*','patient-diagnosis-test*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor|Receptionist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Diagnosis Categories',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('diagnosis-categories*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('diagnosis.category.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.diagnosis_category.diagnosis_categories')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor|Receptionist|Lab Technician')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Diagnosis Tests',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patient-diagnosis-test*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('patient.diagnosis.test.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_test')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('sms*','mail*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor|Accountant|Case Manager|Receptionist|Pharmacist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'SMS',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('sms*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('sms.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.sms.sms')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Case Manager|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Mail',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('mail*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('mail')); ?>">
            <span class="menu-title"><?php echo e(__('messages.mail')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('incomes*','expenses*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Income',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('incomes*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('incomes.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.incomes.incomes')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Accountant')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Expense',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('expenses*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('expenses.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.expenses')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('item-categories*','items*','item-stocks*','issued-items*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Items Categories',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('item-categories*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('item-categories.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.items_categories')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Items',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('items*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('items.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.items')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Item Stocks',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('item-stocks*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('item.stock.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.items_stocks')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Issued Items',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('issued-items*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('issued.item.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.issued_items')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('charge-categories*','charges*','doctor-opd-charges*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Charge Categories',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('charge-categories*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('charge-categories.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.charge_categories')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Charges',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('charges*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('charges.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.charges')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctor OPD Charges',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('doctor-opd-charges*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('doctor-opd-charges.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.doctor_opd_charges')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('call-logs*','visitor*','receives*','dispatches*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Call Logs',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('call-logs*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('call_logs.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.call_logs')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Visitors',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('visitor*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('visitors.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.visitors')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Postal Receive',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('receives*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('receives.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.postal_receive')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Postal Dispatch',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('dispatches*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('dispatches.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.postal_dispatch')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('live-consultation*','live-meeting*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor|Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Consultations',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('live-consultation*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('live.consultation.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.live_consultations')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Doctor|Accountant|Case Manager|Receptionist|Pharmacist|Lab Technician|Nurse')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Meetings',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('live-meeting*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('live.meeting.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.live_meetings')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php ($sectionName = (Request::get('section') === null && !Request::is('hospital-schedules')) ? 'general' : Request::get('section')); ?>
<div
        class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((Request::is('settings*','hospital-schedules')) ? '' : 'd-none'); ?>"
        id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e((isset($sectionName) && $sectionName == 'general') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('settings.edit', ['section' => 'general'])); ?>">
            <span class="menu-title"><?php echo e(__('messages.general')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('hospital-schedules*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('hospital-schedules.index')); ?>">
            <span class="menu-title">Hospital Schedules</span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e((isset($sectionName) && $sectionName == 'sidebar_setting') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('settings.edit', ['section' => 'sidebar_setting'])); ?>">
            <span class="menu-title"><?php echo e(__('messages.sidebar_setting')); ?></span>
        </a>
    </div>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('front-settings*','notice-boards*','testimonials*', 'front-cms-services*','terms-and-conditions*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('front-settings*') ? 'show' : ''); ?>">
        <a class="menu-link py-3" href="<?php echo e(route('front.settings.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.cms')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('front-cms-services*') ? 'show' : ''); ?>">
        <a class="menu-link py-3" href="<?php echo e(route('front.cms.services.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.front_cms_services')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('notice-boards*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(url('notice-boards')); ?>">
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Testimonial',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('testimonials*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('testimonials.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.testimonials')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('enquiries*','enquiry*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Receptionist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Enquires',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('enquiries*') || Request::is('enquiry*') ? 'show' : ''); ?>">
        <a class="menu-link py-3" href="<?php echo e(route('enquiries')); ?>">
            <span class="menu-title"><?php echo e(__('messages.enquiries')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/doctor*','prescriptions*','schedules*','doctors*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Doctor')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/doctor*','doctors*') ? 'show' : ''); ?>">
        <a class="menu-link py-3" href="<?php echo e(url('employee/doctor')); ?>">
            <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Schedules',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('schedules*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('schedules.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.schedules')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Prescriptions',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('prescriptions*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('prescriptions.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.prescriptions')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/notice-board*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Doctor|Accountant|Case Manager|Receptionist|Pharmacist|Lab Technician|Nurse|Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/notice-board*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(url('employee/notice-board')); ?>">
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/payroll*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Doctor|Accountant|Case Manager|Receptionist|Pharmacist|Lab Technician|Nurse')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/payroll*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('payroll')); ?>">
            <span class="menu-title"><?php echo e(__('messages.my_payrolls')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('patient/my-cases*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Patient Cases',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patient/my-cases*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(url('patient/my-cases')); ?>">
            <span class="menu-title"><?php echo e(__('messages.patients_cases')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/patient-admissions*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Patient Admissions',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/patient-admissions*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(url('employee/patient-admissions')); ?>">
            <span class="menu-title"><?php echo e(__('messages.patient_admissions')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('patient/my-prescriptions*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Prescriptions',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patient/my-prescriptions*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('prescriptions.list')); ?>">
            <span class="menu-title"><?php echo e(__('messages.prescriptions')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('patient/my-vaccinated*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Vaccinated Patients',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patient/my-vaccinated*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('patient.vaccinated')); ?>">
            <span class="menu-title"><?php echo e(__('messages.vaccinated_patients')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('patient/my-ipds*','opds*','patient/my-opds*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'IPD Patients',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('patient/my-ipds*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('patient.ipd')); ?>">
            <span class="menu-title"><?php echo e(__('messages.ipd_patients')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'OPD Patients',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('opds*','patient/my-opds*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(route('patient.opd')); ?>">
            <span class="menu-title"><?php echo e(__('messages.opd_patients')); ?></span>
        </a>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/patient-diagnosis-test*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Diagnosis Tests',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/patient-diagnosis-test*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(url('employee/patient-diagnosis-test')); ?>">
            <span class="menu-title"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_test')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/invoices*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Invoices',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/invoices*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(url('employee/invoices')); ?>">
            <span class="menu-title"><?php echo e(__('messages.invoices')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<div
    class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('employee/bills*')) ? 'd-none' : ''); ?>"
    id="#kt_header_menu" data-kt-menu="true">
    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Bills',$modules)): ?>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('employee/bills*') ? 'show' : ''); ?>">
        <a class="menu-link py-3"
           href="<?php echo e(url('employee/bills')); ?>">
            <span class="menu-title"><?php echo e(__('messages.bills')); ?></span>
        </a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php if(auth()->check() && auth()->user()->hasRole('Super Admin')): ?>

<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('super-admin/dashboard*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/dashboard*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('super.admin.dashboard')); ?>">
            <span class="menu-title"><?php echo e(__('messages.dashboard.dashboard')); ?></span>
        </a>
    </div>
</div>


<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('super-admin/hospitals*', 'super-admin/hospital*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/hospitals*', 'super-admin/hospital*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('super.admin.hospitals.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.hospitals')); ?></span>
        </a>
    </div>
</div>


<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('super-admin/subscription-plans*', 'super-admin/transactions*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/subscription-plans*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('super.admin.subscription.plans.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.subscription_plans.subscription_plans')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/transactions*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 <?php echo e(Request::is('super-admin/transactions*') ? 'active' : ''); ?>"
           href="<?php echo e(route('subscriptions.transactions.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.subscription_plans.transactions')); ?></span>
        </a>
    </div>
</div>


<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('super-admin/section-one*','super-admin/section-two*','super-admin/section-three*','super-admin/section-four*','super-admin/section-five*','super-admin/about-us*','super-admin/service-slider*','super-admin/faqs*','super-admin/admin-testimonial*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/section-one*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('super.admin.section.one')); ?>">
            <span class="menu-title"><?php echo e(__('messages.landing_cms.section_one')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/section-two*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('super.admin.section.two')); ?>">
            <span class="menu-title"><?php echo e(__('messages.landing_cms.section_two')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/section-three*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('super.admin.section.three')); ?>">
            <span class="menu-title"><?php echo e(__('messages.landing_cms.section_three')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/section-four*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('super.admin.section.four')); ?>">
            <span class="menu-title"><?php echo e(__('messages.landing_cms.section_four')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/section-five*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('super.admin.section.five')); ?>">
            <span class="menu-title"><?php echo e(__('messages.landing_cms.section_five')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/about-us*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('super.admin.about.us')); ?>">
            <span class="menu-title"><?php echo e(__('messages.landing_cms.about_us')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/service-slider*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('service-slider.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.web_home.services')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/faqs*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('faqs.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.faqs.faqs')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/admin-testimonial') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('admin-testimonial.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.testimonials')); ?></span>
        </a>
    </div>
</div>


<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('super-admin/general-settings*','super-admin/footer-settings*')) ? 'd-none' : ''); ?>" id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/general-settings*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 " href="<?php echo e(route('super.admin.settings.edit')); ?>">
            <span class="menu-title"><?php echo e(__('messages.settings')); ?></span>
        </a>
    </div>
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/footer-settings*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('super.admin.footer.settings.edit')); ?>">
            <span class="menu-title"><?php echo e(__('messages.footer_setting.footer_settings')); ?></span>
        </a>
    </div>
</div>


<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('super-admin/subscriber*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/subscriber*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('super.admin.subscribe.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.subscribe.subscribers')); ?></span>
        </a>
    </div>
</div>


<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch <?php echo e((!Request::is('super-admin/enquiries*')) ? 'd-none' : ''); ?>"
     id="#kt_header_menu" data-kt-menu="true">
    <div class="menu-item me-lg-1 <?php echo e(Request::is('super-admin/enquiries*') ? 'show' : ''); ?>">
        <a class="menu-link py-3 "
           href="<?php echo e(route('super.admin.enquiry.index')); ?>">
            <span class="menu-title"><?php echo e(__('messages.enquiries')); ?></span>
        </a>
    </div>
</div>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/layouts/sub_menu.blade.php ENDPATH**/ ?>