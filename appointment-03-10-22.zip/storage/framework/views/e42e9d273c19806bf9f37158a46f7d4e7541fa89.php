<table class="table table-responsive-sm align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100"
       id="tblInvoices">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <th><?php echo e(__('messages.invoice.invoice_id')); ?></th>
        <th><?php echo e(__('messages.invoice.patient')); ?></th>
        <th><?php echo e(__('messages.invoice.invoice_date')); ?></th>
        <th><?php echo e(__('messages.invoice.amount')); ?></th>
        <th><?php echo e(__('messages.common.status')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/employees/invoices/table.blade.php ENDPATH**/ ?>