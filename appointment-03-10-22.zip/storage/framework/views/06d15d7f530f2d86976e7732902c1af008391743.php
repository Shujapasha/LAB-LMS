<table class="table table-responsive-sm align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100"
       id="patientAdmissionsTbl">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <th><?php echo e(__('messages.bill.admission_id')); ?></th>
        <th><?php echo e(__('messages.patient_admission.patient')); ?></th>
        <th><?php echo e(__('messages.patient_admission.doctor')); ?></th>
        <th><?php echo e(__('messages.patient_admission.admission_date')); ?></th>
        <th><?php echo e(__('messages.patient_admission.discharge_date')); ?></th>
        <th><?php echo e(__('messages.patient_admission.package')); ?></th>
        <th><?php echo e(__('messages.patient_admission.insurance')); ?></th>
        <th><?php echo e(__('messages.patient_admission.policy_no')); ?></th>
        <th><?php echo e(__('messages.common.status')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/employees/patient_admissions/table.blade.php ENDPATH**/ ?>