<?php 
    $settingValue = getSuperAdminSettingValue();
?>
<header id="site-header" class="header header-3">
    <div id="header-wrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Navbar -->
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand logo" href="<?php echo e(route('landing.home')); ?>">
                            <img id="logo-img" class="img-fluid"
                                 src="<?php echo e($settingValue['app_logo']['value']); ?>"
                                 alt="">
                        </a>
                        <div class="right-nav align-items-center d-sm-none d-flex justify-content-end right-sm-nav">
                            <?php if(!empty(getLoggedInUser()) && getLoggedInUser()->hasRole('Admin')): ?>
                                <a class="btn btn-theme btn-sm" href="<?php echo e(route('dashboard')); ?>"><span><?php echo e(__('Dashboard')); ?></span></a>
                            <?php elseif(!empty(getLoggedInUser()) && getLoggedInUser()->hasRole('Super Admin')): ?>
                                <a class="btn btn-theme btn-sm" href="<?php echo e(route('super.admin.dashboard')); ?>"><span><?php echo e(__('Dashboard')); ?></span></a>
                            <?php else: ?>
                                <a class="btn btn-theme btn-sm" href="<?php echo e(route('login')); ?>"><span><?php echo e(__('messages.web_menu.login')); ?></span></a>
                            <?php endif; ?>
                        </div>
                        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul class="navbar-nav mx-auto">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>"
                                       href="<?php echo e(route('landing.home')); ?>"><?php echo e(__('messages.landing.home')); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(Request::is('about-us') ? 'active' : ''); ?>"
                                       href="<?php echo e(route('landing.about.us')); ?>"><?php echo e(__('messages.landing.about')); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(Request::is('our-services') ? 'active' : ''); ?>"
                                       href="<?php echo e(route('landing.services')); ?>"><?php echo e(__('messages.services')); ?></a>
                                </li>
                                <?php if(getLoggedInUser() == null || !getLoggedInUser()->hasRole('Super Admin')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(Request::is('pricing') ? 'active' : ''); ?>"
                                           href="<?php echo e(route('landing.pricing')); ?>"><?php echo e(__('messages.landing.pricing')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(Request::is('contact-us') ? 'active' : ''); ?>"
                                       href="<?php echo e(route('landing.contact.us')); ?>"><?php echo e(__('messages.enquiry.contact')); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(Request::is('faqs') ? 'active' : ''); ?>"
                                       href="<?php echo e(route('landing.faq')); ?>"><?php echo e(__('messages.landing.faqs')); ?></a>
                                </li>
                            </ul>
                            <div class="header-call d-flex align-items-center me-3 d-sm-none d-block header-sm-call">
                                <h5><?php echo e(__('messages.landing.call')); ?>:</h5>
                                <a href="tel:<?php echo e($settingValue['phone']['value']); ?>"><b><?php echo e($settingValue['phone']['value']); ?></b></a>
                            </div>
                        </div>
                        <div class="right-nav align-items-center d-sm-flex justify-content-end d-none ms-auto me-3">
                            <div class="header-call d-flex align-items-center me-3">
                                <h5><?php echo e(__('messages.landing.call')); ?>:</h5>
                                <a href="tel:<?php echo e($settingValue['phone']['value']); ?>"><b><?php echo e($settingValue['phone']['value']); ?></b></a>
                            </div>
                            <?php if(!empty(getLoggedInUser()) && getLoggedInUser()->hasRole('Admin')): ?>
                                <a class="btn btn-theme btn-sm" href="<?php echo e(route('dashboard')); ?>"><span><?php echo e(__('Dashboard')); ?></span></a>
                            <?php elseif(!empty(getLoggedInUser()) && getLoggedInUser()->hasRole('Super Admin')): ?>
                                <a class="btn btn-theme btn-sm" href="<?php echo e(route('super.admin.dashboard')); ?>"><span><?php echo e(__('Dashboard')); ?></span></a>
                            <?php else: ?>
                                <a class="btn btn-theme btn-sm" href="<?php echo e(route('login')); ?>"><span><?php echo e(__('messages.web_menu.login')); ?></span></a>
                            <?php endif; ?>
                        </div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarNavDropdown" aria-expanded="false"
                                aria-label="Toggle navigation"><span class="menu-line"></span>
                            <span class="menu-line"></span>
                            <span class="menu-line"></span>
                            <span class="line-one"></span>
                            <span class="line-two"></span>
                        </button>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/landing/layouts/header.blade.php ENDPATH**/ ?>