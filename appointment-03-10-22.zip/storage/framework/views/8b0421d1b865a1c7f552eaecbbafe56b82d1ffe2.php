<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.settings')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/int-tel/css/intlTelInput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sub-header.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-body pt-0 fs-6 py-8 px-8  px-lg-10 text-gray-700">
            <?php echo $__env->yieldContent('section'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
    <script src="<?php echo e(asset('assets/js/int-tel/js/intlTelInput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/int-tel/js/utils.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let utilsScript = "<?php echo e(asset('assets/js/int-tel/js/utils.min.js')); ?>";
        let isEdit = true;
        let moduleUrl = '<?php echo e(route('module.index')); ?>';
        let imageValidation = '<?php echo e(__('messages.setting.image_validation')); ?>';
        let searchExist = false;
    </script>
    <script src="<?php echo e(mix('assets/js/settings/setting.js')); ?>"></script>
    <script src="<?php echo e(mix('assets/js/custom/phone-number-country-code.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appointment\resources\views/settings/edit.blade.php ENDPATH**/ ?>