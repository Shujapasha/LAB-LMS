<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\appointment\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>