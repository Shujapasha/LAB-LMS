<div class="nav nav-tabs nav-group nav-group-outline justify-content-center mx-auto mb-5 border-0"
     data-kt-buttons="true">
    <a class="btn btn-theme btn-circle nav-link  border-0 px-sm-6 px-4 py-sm-3 py-2 m-sm-2 m-1 active"
       id="month-tab" data-bs-toggle="tab" href="#monthContent"><span><?php echo e(__('messages.month')); ?></span></a>
    <a class="btn btn-theme btn-circle nav-link  border-0 px-sm-6 px-4 py-sm-3 py-2 m-sm-2 m-1"
       id="year-tab" data-bs-toggle="tab" href="#yearContent"><span><?php echo e(__('messages.year')); ?></span></a>
</div>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/landing/home/pricing_plan_button.blade.php ENDPATH**/ ?>