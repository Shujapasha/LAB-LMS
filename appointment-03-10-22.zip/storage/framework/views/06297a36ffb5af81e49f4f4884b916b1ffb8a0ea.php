<div class="row gx-10 mb-9">
    <div class="col-12">
        <div class="main-card-section p-0">
            <?php $__currentLoopData = $weekDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $shortWeekDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($isValid = $hospitalSchedules->where('day_of_week',$day)->count() != 0); ?>
                <div class="weekly-content" data-day="<?php echo e($day); ?>">
                    <div class="d-flex w-100 align-items-center position-relative">
                        <div class="d-flex flex-md-row flex-column w-100 weekly-row">
                            <div
                                class="form-check form-check-custom form-check-solid mb-0 checkbox-content d-flex align-items-center">
                                <input id="chkShortWeekDay_<?php echo e($shortWeekDay); ?>" class="form-check-input" type="checkbox"
                                       value="<?php echo e($day); ?>" name="checked_week_days[]"
                                       <?php if($isValid): ?>
                                       checked="checked" <?php endif; ?>>
                                <label class="form-check-label" for="chkShortWeekDay_<?php echo e($shortWeekDay); ?>">
                                    <span class="fs-5 fw-bold d-md-block d-none"><?php echo e($shortWeekDay); ?></span>
                                </label>
                            </div>
                            <div class="session-times">
                                <?php if($hospitalSchedule = $hospitalSchedules->where('day_of_week',$day)->first()): ?>
                                    <?php echo $__env->make('hospital_schedule.slot',['slot' => $slots,'day' => $day,'hospitalSchedule' => $hospitalSchedule], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <?php echo $__env->make('hospital_schedule.slot',['slot' => $slots,'day' => $day], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<div>
    <?php echo e(Form::button(__('messages.common.save'), ['type' => 'submit','class' => 'btn btn-primary', 'id' => 'btnSave','data-loading-text' => "<span class='spinner-border spinner-border-sm'></span> Processing..."])); ?>

</div>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/hospital_schedule/fields.blade.php ENDPATH**/ ?>