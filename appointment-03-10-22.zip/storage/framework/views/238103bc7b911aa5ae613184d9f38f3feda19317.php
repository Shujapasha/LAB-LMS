<table class="table table-responsive-sm align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100" id="appointmentsTbl">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <?php if(Auth::user()->hasRole('Admin') || Auth::user()->hasRole('Doctor')): ?>
            <th></th>
        <?php endif; ?>
        <th><?php echo e(__('messages.case.patient')); ?></th>
        <th><?php echo e(__('messages.case.doctor')); ?></th>
        <th><?php echo e(__('messages.appointment.doctor_department')); ?></th>
        <th><?php echo e(__('messages.appointment.date')); ?></th>
        <th><?php echo e(__('messages.common.action')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/appointments/table.blade.php ENDPATH**/ ?>