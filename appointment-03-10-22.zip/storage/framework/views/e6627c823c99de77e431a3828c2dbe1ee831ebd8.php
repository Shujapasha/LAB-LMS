<table class="table table-responsive-sm align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100"
       id="chargeCategoriesTbl">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <th><?php echo e(__('messages.charge.charge_category')); ?></th>
        <th><?php echo e(__('messages.common.description')); ?></th>
        <th><?php echo e(__('messages.charge_category.charge_type')); ?></th>
        <th><?php echo e(__('messages.common.action')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/charge_categories/table.blade.php ENDPATH**/ ?>