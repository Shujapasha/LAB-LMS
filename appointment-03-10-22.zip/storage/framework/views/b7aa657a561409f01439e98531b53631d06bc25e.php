<table class="table align-middle table-responsive-sm table-row-dashed fs-6 gy-5 dataTable no-footer w-100" id="tblDocuments">
    <thead>
    <tr class="fw-bold fs-6 text-muted">
        <th><?php echo e(__('messages.document.attachment')); ?></th>
        <th><?php echo e(__('messages.document.document_type')); ?></th>
        <th><?php echo e(__('messages.document.patient')); ?></th>
        <th><?php echo e(__('messages.common.action')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold"></tbody>
</table>

<?php /**PATH C:\xampp\htdocs\appointment\resources\views/documents/table.blade.php ENDPATH**/ ?>