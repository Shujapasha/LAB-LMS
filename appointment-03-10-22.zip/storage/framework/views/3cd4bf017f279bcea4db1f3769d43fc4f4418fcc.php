<div class="row">
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('test_name', __('messages.radiology_test.test_name').':',['class' => 'form-label required fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('test_name', null, ['class' => 'form-control form-control-solid','required'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('short_name', __('messages.radiology_test.short_name').':',['class' => 'form-label required fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('short_name', null, ['class' => 'form-control form-control-solid','required'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('test_type', __('messages.radiology_test.test_type').':',['class' => 'form-label required fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('test_type', null, ['class' => 'form-control form-control-solid','required'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('category_id', __('messages.radiology_test.category_name').':',['class' => 'form-label required fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::select('category_id',$data['radiologyCategories'], null, ['class' => 'form-select form-select-solid','required','id' => 'categoryName','placeholder'=>'Select Category','required'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('subcategory', __('messages.radiology_test.subcategory').':',['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('subcategory', null, ['class' => 'form-control form-control-solid'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('report_days', __('messages.radiology_test.report_days').':',['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::number('report_days', null, ['class' => 'form-control form-control-solid'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('charge_category_id', __('messages.radiology_test.charge_category').':',['class' => 'form-label required fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::select('charge_category_id',$data['chargeCategories'], null, ['class' => 'form-select form-select-solid','required','id' => 'chargeCategory','placeholder'=>'Select Charge Category','required'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('standard_charge', __('messages.radiology_test.standard_charge').':',['class' => 'form-label required fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            (<b><?php echo e(getCurrencySymbol()); ?></b>)
            <?php echo e(Form::text('standard_charge', null, ['class' => 'form-control price-input form-control-solid', 'id' => 'standardCharge', 'readonly', 'required'])); ?>

        </div>
    </div>
    <div class="d-flex mt-4">
        <div class="form-group">
            <?php echo e(Form::submit(__('messages.common.save'), ['class' => 'btn btn-primary me-3'])); ?>

            <a href="<?php echo e(route('radiology.test.index')); ?>"
               class="btn btn-light btn-active-light-primary me-2"><?php echo e(__('messages.common.cancel')); ?></a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/radiology_tests/fields.blade.php ENDPATH**/ ?>