<?php ($modules = App\Models\Module::cacheFor(now()->addDays())->toBase()->get()); ?>
<div class="position-relative mb-5 mx-3 mt-2 sidebar-search-box">
    <span class="svg-icon svg-icon-1 svg-icon-primary position-absolute top-50 translate-middle ms-9">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24"
                                                                 height="24" viewBox="0 0 24 24" fill="none">
                                                                <rect opacity="0.5" x="17.0365" y="15.1223"
                                                                      width="8.15546" height="2" rx="1"
                                                                      transform="rotate(45 17.0365 15.1223)"
                                                                      fill="black"></rect>
                                                                <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z"
                                                                      fill="black"></path>
                                                            </svg>
                                                        </span>
    <?php
    $style = 'style=';
    $background = 'background-color:';
    $border = 'border:';
    $color = 'color:';
    ?>

    <input type="text" class="form-control form-control-lg form-control-solid ps-15" id="menuSearch" name="search"
           value="" placeholder="Search" autocomplete="off" <?php echo e($style); ?>"<?php echo e($background); ?> #2A2B3A;<?php echo e($border); ?>

    none;<?php echo e($color); ?> #FFFFFF;">
</div>
<div class="no-record text-white text-center d-none">No matching records found</div>
<?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>

<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
        <span class="menu-icon">
            <i class="fas fa-chart-pie"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.dashboard.dashboard')); ?></span>
    </a>
</div>


<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Accountants',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('accountants*') ? 'active' : ''); ?>"
           href="<?php echo e(route('accountants.index')); ?>">
            <span class="menu-icon"><i class="fas fa-file-invoice"></i></span>
            <span class="menu-title"><?php echo e(__('messages.accountants')); ?></span>
        </a>
    </div>
<?php endif; ?>




<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Appointments',$modules)): ?>
<?php if(isFeatureAllowToUse('appointments.index')): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('appointment*') ? 'active' : ''); ?>"
           href="<?php echo e(route('appointments.index')); ?>">
            <span class="menu-icon"><i class="fas fa-calendar-check"></i></span>
            <span class="menu-title"><?php echo e(__('messages.appointments')); ?></span>
        </a>
    </div>
<?php endif; ?>
<?php endif; ?>


<?php
$billingMGT = getMenuLinks(\App\Models\User::MAIN_BILLING_MGT);
?>
<?php if($billingMGT): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('accounts*','employee-payrolls*','invoices*','payments*','payment-reports*','advanced-payments*','bills*') ? 'active' : ''); ?>"
           href="<?php echo e($billingMGT); ?>">
            <span class="menu-icon"><i class="fas fa-file-invoice-dollar"></i></span>
            <span class="menu-title"><?php echo e(__('messages.billing')); ?></span>
            <span class="d-none"><?php echo e(__('messages.employee_payrolls')); ?></span>
            <span class="d-none"><?php echo e(__('messages.invoices')); ?></span>
            <span class="d-none"><?php echo e(__('messages.payments')); ?></span>
            <span class="d-none"><?php echo e(__('messages.payment_reports')); ?></span>
            <span class="d-none"><?php echo e(__('messages.advanced_payments')); ?></span>
            <span class="d-none"><?php echo e(__('messages.bills')); ?></span>
        </a>
    </div>
<?php endif; ?>

<?php
$bedMGT = getMenuLinks(\App\Models\User::MAIN_BED_MGT)
?>
<?php if($bedMGT): ?>
    
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('bed-types*','beds*','bed-assigns*','bulk-beds','bed-status') ? 'active' : ''); ?>"
           href="<?php echo e($bedMGT); ?>">
            <span class="menu-icon"><i class="fas fa-bed"></i></span>
            <span class="menu-title"><?php echo e(__('messages.bed_management')); ?></span>
            <span class="d-none"><?php echo e(__('messages.bed_types')); ?></span>
            <span class="d-none"><?php echo e(__('messages.beds')); ?></span>
            <span class="d-none"><?php echo e(__('messages.bed_assigns')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php if(isFeatureAllowToUse('blood-banks.index')): ?>
    
    <?php
    $bloodbankMGT = getMenuLinks(\App\Models\User::MAIN_BLOOD_BANK_MGT)
    ?>
    <?php if($bloodbankMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('blood-banks*','blood-donors*','blood-donations*','blood-issues*') ? 'active' : ''); ?>"
               href="<?php echo e($bloodbankMGT); ?>">
                <span class="menu-icon"><i class="fas fa-tint"></i></span>
                <span class="menu-title"><?php echo e(__('messages.blood_bank')); ?></span>
                <span class="d-none"><?php echo e(__('messages.blood_donors')); ?></span>
                <span class="d-none"><?php echo e(__('messages.blood_donations')); ?></span>
                <span class="d-none"><?php echo e(__('messages.blood_issues')); ?></span>
            </a>
        </div>
    <?php endif; ?>

<?php endif; ?>


<?php if(isFeatureAllowToUse('documents.index')): ?>
    <?php
    $documentMGT = getMenuLinks(\App\Models\User::MAIN_DOCUMENT)
    ?>
    <?php if($documentMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('documents*','document-types*') ? 'active' : ''); ?>"
               href="<?php echo e($documentMGT); ?>">
                <span class="menu-icon"><i class="fas fa-file"></i></span>
                <span class="menu-title"><?php echo e(__('messages.documents')); ?></span>
                <span class="d-none"><?php echo e(__('messages.document_types')); ?></span>
            </a>
        </div>
    <?php endif; ?>

<?php endif; ?>



<?php
$doctorMGT = getMenuLinks(\App\Models\User::MAIN_DOCTOR)
?>
<?php if($doctorMGT): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('doctors*','doctor-departments*', 'doctor-designations*', 'doctor-categories*','schedules*','prescriptions*') ? 'active' : ''); ?>"
           href="<?php echo e($doctorMGT); ?>">
            <span class="menu-icon"><i class="fa fa-user-md"></i></span>
            <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
            <span class="d-none"><?php echo e(__('messages.doctor_departments')); ?></span>
            <span class="d-none"><?php echo e(__('messages.doctor_designations')); ?></span>
            <span class="d-none"><?php echo e(__('messages.doctor_categories')); ?></span>
            <span class="d-none"><?php echo e(__('messages.schedules')); ?></span>
            <span class="d-none"><?php echo e(__('messages.prescriptions')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Referral',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('doctor-referrals*') ? 'active' : ''); ?>"
           href="<?php echo e(route('doctor-referrals.index')); ?>">
            <span class="menu-icon"><i class="fas fa-file-invoice"></i></span>
            <span class="menu-title"><?php echo e(__('messages.referral')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php
$diagnosisMGT = getMenuLinks(\App\Models\User::MAIN_DIAGNOSIS)
?>
<?php if($diagnosisMGT): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('diagnosis-categories*','patient-diagnosis-test*') ? 'active' : ''); ?>"
           href="<?php echo e($diagnosisMGT); ?>">
            <span class="menu-icon"><i class="fas fa-diagnoses"></i></span>
            <span class="menu-title"><?php echo e(__('messages.patient_diagnosis_test.diagnosis')); ?></span>
            <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_category')); ?></span>
            <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_test')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Enquires',$modules)): ?>
<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('enquiries*') || Request::is('enquiry*') ? 'active' : ''); ?>"
       href="<?php echo e(route('enquiries')); ?>">
        <span class="menu-icon"><i class="fas fa-question-circle"></i></span>
        <span class="menu-title"><?php echo e(__('messages.enquiries')); ?></span>
    </a>
</div>
<?php endif; ?>


<?php
$financeMGT = getMenuLinks(\App\Models\User::MAIN_FINANCE)
?>
<?php if($financeMGT): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('incomes*','expenses*') ? 'active' : ''); ?>"
           href="<?php echo e($financeMGT); ?>">
            <span class="menu-icon"><i class="fas fa-money-bill"></i></span>
            <span class="menu-title"><?php echo e(__('messages.finance')); ?></span>
            <span class="d-none"><?php echo e(__('messages.incomes.incomes')); ?></span>
            <span class="d-none"><?php echo e(__('messages.expenses')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php
$frontOfficeMGT = getMenuLinks(\App\Models\User::MAIN_FRONT_OFFICE)
?>
<?php if($frontOfficeMGT): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('call-logs*','visitor*','receives*','dispatches*') ? 'active' : ''); ?>"
           href="<?php echo e($frontOfficeMGT); ?>">
            <span class="menu-icon"><i class="fa fa-dungeon"></i></span>
            <span class="menu-title"><?php echo e(__('messages.front_office')); ?></span>
            <span class="d-none"><?php echo e(__('messages.call_logs')); ?></span>
            <span class="d-none"><?php echo e(__('messages.visitors')); ?></span>
            <span class="d-none"><?php echo e(__('messages.postal_receive')); ?></span>
            <span class="d-none"><?php echo e(__('messages.postal_dispatch')); ?></span>
        </a>
    </div>
<?php endif; ?>


<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('front-settings*','notice-boards*','testimonials*', 'front-cms-services*') ? 'active' : ''); ?>"
       href="<?php echo e(route('front.settings.index')); ?>">
        <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
        <span class="menu-title"><?php echo e(__('messages.front_cms')); ?></span>
        <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        <span class="d-none"><?php echo e(__('messages.testimonials')); ?></span>
        <span class="d-none"><?php echo e(__('messages.cms')); ?></span>
        <span class="d-none"><?php echo e(__('messages.front_cms_services')); ?></span>
    </a>
</div>


<?php
$hospitalCharge = getMenuLinks(\App\Models\User::MAIN_HOSPITAL_CHARGE)
?>
<?php if($hospitalCharge): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('charge-categories*','charges*','doctor-opd-charges*') ? 'active' : ''); ?>"
           href="<?php echo e($hospitalCharge); ?>">
            <span class="menu-icon"><i class="fas fa-coins"></i></span>
            <span class="menu-title"><?php echo e(__('messages.hospital_charges')); ?></span>
            <span class="d-none"><?php echo e(__('messages.charge_categories')); ?></span>
            <span class="d-none"><?php echo e(__('messages.charges')); ?></span>
            <span class="d-none"><?php echo e(__('messages.doctor_opd_charges')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php
$ipdOPD = getMenuLinks(\App\Models\User::MAIN_IPD_OPD)
?>
<?php if($ipdOPD): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('ipds*','opds*') ? 'active' : ''); ?>" href="<?php echo e($ipdOPD); ?>"
           title="<?php echo e(__('messages.ipd_opd')); ?>">
        <span class="menu-icon">
            <i class="fas fa-notes-medical"></i>
        </span>
            <span class="menu-title"><?php echo e(__('messages.ipd_opd')); ?></span>
            <span class="d-none"><?php echo e(__('messages.ipd_patients')); ?></span>
            <span class="d-none"><?php echo e(__('messages.opd_patients')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php if(isFeatureAllowToUse('item-categories.index')): ?>
    <?php
    $inventoryMgt = getMenuLinks(\App\Models\User::MAIN_INVENTORY)
    ?>
    <?php if($inventoryMgt): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('item-categories*','items*','item-stocks*','issued-items*') ? 'active' : ''); ?>"
               href="<?php echo e($inventoryMgt); ?>">
                <span class="menu-icon"><i class="fas fa-luggage-cart"></i></span>
                <span class="menu-title"><?php echo e(__('messages.inventory')); ?></span>
                <span class="d-none"><?php echo e(__('messages.items_categories')); ?></span>
                <span class="d-none"><?php echo e(__('messages.items')); ?></span>
                <span class="d-none"><?php echo e(__('messages.items_stocks')); ?></span>
                <span class="d-none"><?php echo e(__('messages.issued_items')); ?></span>
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Lab Technicians',$modules)): ?>
<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('lab-technicians*') ? 'active' : ''); ?>"
       href="<?php echo e(route('lab-technicians.index')); ?>">
        <span class="menu-icon"><i class="fas fa-microscope"></i></span>
        <span class="menu-title"><?php echo e(__('messages.lab_technicians')); ?></span>
    </a>
</div>
<?php endif; ?>


<?php if(isFeatureAllowToUse('live.consultation.index')): ?>
    <?php
    $liveConsultation = getMenuLinks(\App\Models\User::MAIN_LIVE_CONSULATION)
    ?>
    <?php if($liveConsultation): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-consultation*','live-meeting*') ? 'active' : ''); ?>"
               href="<?php echo e($liveConsultation); ?>">
                <span class="menu-icon"><i class="fa fa-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_consultations')); ?></span>
                <span class="d-none"><?php echo e(__('messages.live_meetings')); ?></span>
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>


<?php
$medicineMgt = getMenuLinks(\App\Models\User::MAIN_MEDICINES)
?>
<?php if($medicineMgt): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('categories*','brands*','medicines*') ? 'active' : ''); ?>"
           href="<?php echo e($medicineMgt); ?>">
            <span class="menu-icon"><i class="fas fa-capsules"></i></span>
            <span class="menu-title"><?php echo e(__('messages.medicines')); ?></span>
            <span class="d-none"><?php echo e(__('messages.medicine_categories')); ?></span>
            <span class="d-none"><?php echo e(__('messages.medicine_brands')); ?></span>
            <span class="d-none"><?php echo e(__('messages.medicines')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Nurses',$modules)): ?>
<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('nurses*') ? 'active' : ''); ?>"
       href="<?php echo e(route('nurses.index')); ?>">
        <span class="menu-icon"><i class="fa fa-user-nurse"></i></span>
        <span class="menu-title"><?php echo e(__('messages.nurses')); ?></span>
    </a>
</div>
<?php endif; ?>


<?php
$patientCaseMgt = getMenuLinks(\App\Models\User::MAIN_PATIENT_CASE)
?>
<?php if($patientCaseMgt): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('patients*','patient-cases*','case-handlers*','patient-admissions*') ? 'active' : ''); ?>"
           href="<?php echo e($patientCaseMgt); ?>">
            <span class="menu-icon"><i class="fas fa-user-injured"></i></span>
            <span class="menu-title"><?php echo e(__('messages.patients')); ?></span>
            <span class="d-none"><?php echo e(__('messages.cases')); ?></span>
            <span class="d-none"><?php echo e(__('messages.case_handlers')); ?></span>
            <span class="d-none"><?php echo e(__('messages.patient_admissions')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Pharmacists',$modules)): ?>
<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('pharmacists*') ? 'active' : ''); ?>"
       href="<?php echo e(route('pharmacists.index')); ?>">
        <span class="menu-icon"><i class="fas fa-file-prescription"></i></span>
        <span class="menu-title"><?php echo e(__('messages.pharmacists')); ?></span>
    </a>
</div>
<?php endif; ?>


<?php if(isFeatureAllowToUse('pathology.category.index')): ?>
    <?php
    $pathologyMgt = getMenuLinks(\App\Models\User::MAIN_PATHOLOGY)
    ?>
    <?php if($pathologyMgt): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('pathology-categories*','pathology-tests*') ? 'active' : ''); ?>"
               href="<?php echo e($pathologyMgt); ?>">
                <span class="menu-icon"><i class="fa fa-flask"></i></span>
                <span class="menu-title"><?php echo e(__('messages.pathologies')); ?></span>
                <span class="d-none"><?php echo e(__('messages.pathology_categories')); ?></span>
                <span class="d-none"><?php echo e(__('messages.pathology_tests')); ?></span>
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('module', 'Receptionists',$modules)): ?>
<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('receptionists*') ? 'active' : ''); ?>"
       href="<?php echo e(route('receptionists.index')); ?>">
        <span class="menu-icon"><i class="fa fa-user-tie"></i></span>
        <span class="menu-title"><?php echo e(__('messages.receptionists')); ?></span>
    </a>
</div>
<?php endif; ?>


<?php if(isFeatureAllowToUse('birth-reports.index')): ?>
    <?php
    $reportMgt = getMenuLinks(\App\Models\User::MAIN_REPORT)
    ?>
    <?php if($reportMgt): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('birth-reports*','death-reports*','investigation-reports*','operation-reports*') ? 'active' : ''); ?>"
               href="<?php echo e($reportMgt); ?>">
                <span class="menu-icon"><i class="fas fa-file-medical"></i></span>
                <span class="menu-title"><?php echo e(__('messages.reports')); ?></span>
                <span class="d-none"><?php echo e(__('messages.birth_reports')); ?></span>
                <span class="d-none"><?php echo e(__('messages.death_reports')); ?></span>
                <span class="d-none"><?php echo e(__('messages.investigation_reports')); ?></span>
                <span class="d-none"><?php echo e(__('messages.operation_reports')); ?></span>
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>


<?php if(isFeatureAllowToUse('radiology.category.index')): ?>
    <?php
    $radiology = getMenuLinks(\App\Models\User::MAIN_RADIOLOGY)
    ?>
    <?php if($radiology): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('radiology-categories*','radiology-tests*') ? 'active' : ''); ?>"
               href="<?php echo e($radiology); ?>">
                <span class="menu-icon"><i class="fa fa-x-ray"></i></span>
                <span class="menu-title"><?php echo e(__('messages.radiologies')); ?></span>
                <span class="d-none"><?php echo e(__('messages.radiology_categories')); ?></span>
                <span class="d-none"><?php echo e(__('messages.radiology_tests')); ?></span>
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>


<?php
$serviceMgt = getMenuLinks(\App\Models\User::MAIN_SERVICE)
?>
<?php if($serviceMgt): ?>
    <div class="menu-item menu-accordion side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('insurances*','packages*','services*','ambulances*','ambulance-calls*') ? 'active' : ''); ?>"
           href="<?php echo e($serviceMgt); ?>">
            <span class="menu-icon"><i class="fas fa-box"></i></span>
            <span class="menu-title"><?php echo e(__('messages.services')); ?></span>
            <span class="d-none"><?php echo e(__('messages.insurances')); ?></span>
            <span class="d-none"><?php echo e(__('messages.packages')); ?></span>
            <span class="d-none"><?php echo e(__('messages.services')); ?></span>
            <span class="d-none"><?php echo e(__('messages.ambulances')); ?></span>
            <span class="d-none"><?php echo e(__('messages.ambulance_calls')); ?></span>
        </a>
    </div>
<?php endif; ?>


<?php if(isFeatureAllowToUse('sms.index')): ?>
    <?php
    $smsMailMgt = getMenuLinks(\App\Models\User::MAIN_SMS_MAIL)
    ?>
    <?php if($smsMailMgt): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('sms*','mail*') ? 'active' : ''); ?>"
               href="<?php echo e($smsMailMgt); ?>"
               title="<?php echo e(__('SMS/Mail')); ?>">
        <span class="menu-icon">    
            <i class="fas fa-bell"></i>
		</span>
                <span class="menu-title"><?php echo e(__('SMS/Mail')); ?></span>
                <span class="d-none"><?php echo e(__('messages.sms.sms')); ?></span>
                <span class="d-none"><?php echo e(__('messages.mail')); ?></span>
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>


<div class="menu-item menu-accordion side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('settings*','hospital-schedule') ? 'active' : ''); ?>"
       href="<?php echo e(route('settings.edit')); ?>">
        <span class="menu-icon"><i class="fa fa-cogs"></i></span>
        <span class="menu-title"><?php echo e(__('messages.settings')); ?></span>
        <span class="d-none"><?php echo e(__('messages.general')); ?></span>
        <span class="d-none"><?php echo e(__('messages.sidebar_setting')); ?></span>
    </a>
</div>



<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('users*') ? 'active' : ''); ?>"
       href="<?php echo e(route('users.index')); ?>">
        <span class="menu-icon">
            <i class="fas fa-user-friends"></i>
        </span>
        <span class="menu-title"><?php echo e(__('messages.users')); ?></span>
    </a>
</div>


<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('my-transactions*') ? 'active' : ''); ?>"
       href="<?php echo e(route('subscriptions.plans.transactions.index')); ?>">
        <span class="menu-icon">
            <i class="fas fa-money-bill-wave"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.subscription_plans.transactions')); ?></span>
    </a>
</div>



<?php if(isFeatureAllowToUse('vaccinated-patients.index')): ?>
    <?php
    $vaccinationsPatient = getMenuLinks(\App\Models\User::MAIN_VACCINATION_MGT)
    ?>
    <?php if($vaccinationsPatient): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('vaccinated-patients*','vaccinations*') ? 'active' : ''); ?>"
               href="<?php echo e($vaccinationsPatient); ?>">
                <span class="menu-icon">
                     <i class="fas fa-syringe"></i>
                </span>
                <span class="menu-title"><?php echo e(__('messages.vaccinations')); ?></span>
                <span class="d-none"><?php echo e(__('messages.vaccinated_patients')); ?></span>
            </a>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php endif; ?>
<?php if(Auth::user()->email_verified_at != null): ?>
    <?php if(auth()->check() && auth()->user()->hasRole('Doctor')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Appointments',$modules)): ?>
    <?php if(isFeatureAllowToUse('appointments.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('appointments*') ? 'active' : ''); ?>"
               href="<?php echo e(route('appointments.index')); ?>">
                <span class="menu-icon"><i class="nav-icon fas fa-calendar-check"></i></span>
                <span class="menu-title"><?php echo e(__('messages.appointments')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php
    $bedDoctorMGT = getMenuLinks(\App\Models\User::MAIN_DOCTOR_BED_MGT)
    ?>
    <?php if($bedDoctorMGT): ?>
        
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('bed-assigns*') ? 'active' : ''); ?>"
               href="<?php echo e($bedDoctorMGT); ?>">
                <span class="menu-icon"><i class="fas fa-bed"></i></span>
                <span class="menu-title"><?php echo e(__('messages.bed_management')); ?></span>
                <span class="d-none"><?php echo e(__('messages.bed_assigns')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/doctor*','prescriptions*','schedules*','doctors*') ? 'active' : ''); ?>"
           href="<?php echo e(route('doctor')); ?>">
            <span class="menu-icon"><i class="fa fa-user-md"></i></span>
            <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
            <span class="d-none"><?php echo e(__('messages.schedules')); ?></span>
            <span class="d-none"><?php echo e(__('messages.prescriptions')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Documents',$modules)): ?>
    <?php if(isFeatureAllowToUse('documents.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('documents*') ? 'active' : ''); ?>"
               href="<?php echo e(route('documents.index')); ?>">
                <span class="menu-icon"><i class="fas fa-file"></i></span>
                <span class="menu-title"><?php echo e(__('messages.documents')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php
    $diagnosisDoctorMGT = getMenuLinks(\App\Models\User::MAIN_DIAGNOSIS)
    ?>
    <?php if($diagnosisDoctorMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('diagnosis-categories*','patient-diagnosis-test*') ? 'active' : ''); ?>"
               href="<?php echo e($diagnosisDoctorMGT); ?>">
                <span class="menu-icon"><i class="fas fa-diagnoses"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patient_diagnosis_test.diagnosis')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_category')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_test')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board*') ? 'active' : ''); ?>"
           href="<?php echo e(url('employee/notice-board')); ?>">
            <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
            <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>

    
    <?php
    $ipdOPD = getMenuLinks(\App\Models\User::MAIN_IPD_OPD)
    ?>
    <?php if($ipdOPD): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('ipds*','opds*') ? 'active' : ''); ?>"
               href="<?php echo e($ipdOPD); ?>"
               title="<?php echo e(__('messages.ipd_opd')); ?>">
        <span class="menu-icon">
            <i class="fas fa-notes-medical"></i>
		</span>
                <span class="menu-title"><?php echo e(__('messages.ipd_opd')); ?></span>
                <span class="d-none"><?php echo e(__('messages.ipd_patients')); ?></span>
                <span class="d-none"><?php echo e(__('messages.opd_patients')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if(isFeatureAllowToUse('live.consultation.index')): ?>
        <?php
        $liveConsultation = getMenuLinks(\App\Models\User::MAIN_LIVE_CONSULATION)
        ?>
        <?php if($liveConsultation): ?>
            <div class="menu-item menu-accordion side-menus">
                <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-consultation*','live-meeting*') ? 'active' : ''); ?>"
                   href="<?php echo e($liveConsultation); ?>">
                    <span class="menu-icon"><i class="fa fa-video"></i></span>
                    <span class="menu-title"><?php echo e(__('messages.live_consultations')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.live_meetings')); ?></span>
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/payroll') ? 'active' : ''); ?>"
           href="<?php echo e(route('payroll')); ?>">
            <span class="menu-icon"><i class="fas fa-chart-pie"></i></span>
            <span class="menu-title"><?php echo e(__('messages.my_payrolls')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php
    $patientDoctorCaseMgt = getMenuLinks(\App\Models\User::MAIN_DOCTOR_PATIENT_CASE)
    ?>
    <?php if($patientDoctorCaseMgt): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('patient-admissions*') ? 'active' : ''); ?>"
               href="<?php echo e($patientDoctorCaseMgt); ?>">
                <span class="menu-icon"><i class="fas fa-user-injured"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patients')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_admissions')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if(isFeatureAllowToUse('birth-reports.index')): ?>
        
        <?php
        $reportDoctorMgt = getMenuLinks(\App\Models\User::MAIN_REPORT)
        ?>
        <?php if($reportDoctorMgt): ?>
            <div class="menu-item menu-accordion side-menus">
                <a class="menu-link menu-text-wrap <?php echo e(Request::is('birth-reports*','death-reports*','investigation-reports*','operation-reports*') ? 'active' : ''); ?>"
                   href="<?php echo e($reportDoctorMgt); ?>">
                    <span class="menu-icon"><i class="fas fa-file-medical"></i></span>
                    <span class="menu-title"><?php echo e(__('messages.reports')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.birth_reports')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.death_reports')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.investigation_reports')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.operation_reports')); ?></span>
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'SMS',$modules)): ?>
    <?php if(isFeatureAllowToUse('sms.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('sms*') ? 'active' : ''); ?>"
               href="<?php echo e(route('sms.index')); ?>">
                <span class="menu-icon"><i class="fas fa fa-sms"></i></span>
                <span class="menu-title"><?php echo e(__('messages.sms.sms')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('Case Manager')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/doctor*') ? 'active' : ''); ?>"
               href="<?php echo e(route('doctor')); ?>">
                <span class="menu-icon"><i class="fa fa-user-md"></i></span>
                <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board*') ? 'active' : ''); ?>"
               href="<?php echo e(url('employee/notice-board')); ?>">
                <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
                <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
                <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
            </a>
        </div>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Meetings',$modules)): ?>
    <?php if(isFeatureAllowToUse('live.meeting.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-meeting*') ? 'active' : ''); ?>"
               href="<?php echo e(route('live.meeting.index')); ?>">
                <span class="menu-icon"><i class="fa fa-file-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_meetings')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/payroll') ? 'active' : ''); ?>"
           href="<?php echo e(route('payroll')); ?>">
            <span class="menu-icon"><i class="fas fa-chart-pie"></i></span>
            <span class="menu-title"><?php echo e(__('messages.my_payrolls')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php
    $patientCaseMangerCaseMgt = getMenuLinks(\App\Models\User::MAIN_CASE_MANGER_PATIENT_CASE)
    ?>
    <?php if($patientCaseMangerCaseMgt): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('patient-admissions*','patient-cases*') ? 'active' : ''); ?>"
               href="<?php echo e($patientCaseMangerCaseMgt); ?>"
               title="<?php echo e(__('Patients')); ?>">
                <span class="menu-icon"><i class="fas fa-user-injured"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patients')); ?></span>
                <span class="d-none"><?php echo e(__('messages.case_handlers')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_admissions')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php
    $serviceCaseMangerCaseMgt = getMenuLinks(\App\Models\User::MAIN_CASE_MANGER_PATIENT_CASE)
    ?>
    <?php if($serviceCaseMangerCaseMgt): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('ambulances*','ambulance-calls*') ? 'active' : ''); ?>"
               href="<?php echo e($serviceCaseMangerCaseMgt); ?>"
               title="<?php echo e(__('Services')); ?>">
                <span class="menu-icon"><i class="fas fa-box"></i></span>
                <span class="menu-title"><?php echo e(__('messages.services')); ?></span>
                <span class="d-none"><?php echo e(__('messages.ambulances')); ?></span>
                <span class="d-none"><?php echo e(__('messages.ambulance_calls')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if(isFeatureAllowToUse('sms.index')): ?>
        <?php
        $smsMailCaseManagerMgt = getMenuLinks(\App\Models\User::MAIN_SMS_MAIL)
        ?>
        <?php if($smsMailCaseManagerMgt): ?>
            <div class="menu-item side-menus">
                <a class="menu-link menu-text-wrap <?php echo e(Request::is('sms*','mail*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('sms.index')); ?>"
                   title="<?php echo e(__('SMS/Mail')); ?>">
        <span class="menu-icon">
            <i class="fas fa-bell"></i>
		</span>
                    <span class="menu-title"><?php echo e(__('SMS/Mail')); ?></span>
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('Receptionist')): ?>
    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Appointments',$modules)): ?>
    <?php if(isFeatureAllowToUse('appointments.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('appointments*') ? 'active' : ''); ?>"
               href="<?php echo e(route('appointments.index')); ?>">
                <span class="menu-icon"><i class="fas fa-calendar-check"></i></span>
                <span class="menu-title"><?php echo e(__('messages.appointments')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('doctors*') ? 'active' : ''); ?>"
           href="<?php echo e(route('doctors.index')); ?>">
            <span class="menu-icon"><i class="fa fa-user-md"></i></span>
            <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php
    $diagnosisReceptionistMGT = getMenuLinks(\App\Models\User::MAIN_DIAGNOSIS)
    ?>
    <?php if($diagnosisReceptionistMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('diagnosis-categories*','patient-diagnosis-test*') ? 'active' : ''); ?>"
               href="<?php echo e($diagnosisReceptionistMGT); ?>">
                <span class="menu-icon"><i class="fas fa-diagnoses"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patient_diagnosis_test.diagnosis')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_category')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_test')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Enquires',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('enquiries*') || Request::is('enquiry*') ? 'active' : ''); ?>"
           href="<?php echo e(route('enquiries')); ?>">
            <span class="menu-icon"><i class="fas fa-question-circle"></i></span>
            <span class="menu-title"><?php echo e(__('messages.enquiries')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php
    $frontReceptionistOfficeMGT = getMenuLinks(\App\Models\User::MAIN_FRONT_OFFICE)
    ?>
    <?php if($frontReceptionistOfficeMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('call-logs*','visitor*','receives*','dispatches*') ? 'active' : ''); ?>"
               href="<?php echo e($frontReceptionistOfficeMGT); ?>">
                <span class="menu-icon"><i class="fa fa-dungeon"></i></span>
                <span class="menu-title"><?php echo e(__('messages.front_office')); ?></span>
                <span class="d-none"><?php echo e(__('messages.call_logs')); ?></span>
                <span class="d-none"><?php echo e(__('messages.visitors')); ?></span>
                <span class="d-none"><?php echo e(__('messages.postal_receive')); ?></span>
                <span class="d-none"><?php echo e(__('messages.postal_dispatch')); ?></span>
            </a>
        </div>  
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board','testimonials*') ? 'active' : ''); ?>"
           href="<?php echo e(route('noticeboard')); ?>">
            <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
            <span class="menu-title"><?php echo e(__('messages.front_settings')); ?></span>
            <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php
    $ReceptionisthospitalCharge = getMenuLinks(\App\Models\User::MAIN_HOSPITAL_CHARGE)
    ?>
    <?php if($ReceptionisthospitalCharge): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('charge-categories*','charges*','doctor-opd-charges*') ? 'active' : ''); ?>"
               href="<?php echo e($ReceptionisthospitalCharge); ?>">
                <span class="menu-icon"><i class="fas fa-coins"></i></span>
                <span class="menu-title"><?php echo e(__('messages.hospital_charges')); ?></span>
                <span class="d-none"><?php echo e(__('messages.charge_categories')); ?></span>
                <span class="d-none"><?php echo e(__('messages.charges')); ?></span>
                <span class="d-none"><?php echo e(__('messages.doctor_opd_charges')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php
    $receptionistIpdOPD = getMenuLinks(\App\Models\User::MAIN_IPD_OPD)
    ?>
    <?php if($receptionistIpdOPD): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('ipds*','opds*') ? 'active' : ''); ?>"
               href="<?php echo e($receptionistIpdOPD); ?>"
               title="<?php echo e(__('messages.ipd_opd')); ?>">
    <span class="menu-icon">
        <i class="fas fa-notes-medical"></i>
    </span>
                <span class="menu-title"><?php echo e(__('messages.ipd_opd')); ?></span>
                <span class="d-none"><?php echo e(__('messages.ipd_patients')); ?></span>
                <span class="d-none"><?php echo e(__('messages.opd_patients')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Meetings',$modules)): ?>
    <?php if(isFeatureAllowToUse('live.meeting.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-meeting*') ? 'active' : ''); ?>"
               href="<?php echo e(route('live.meeting.index')); ?>">
                <span class="menu-icon"><i class="fa fa-file-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_meetings')); ?></span>
                <span class="d-none"><?php echo e(__('messages.live_meetings')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/payroll') ? 'active' : ''); ?>"
           href="<?php echo e(route('payroll')); ?>">
            <span class="menu-icon"><i class="fas fa-chart-pie"></i></span>
            <span class="menu-title"><?php echo e(__('messages.my_payrolls')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php
    $receptionistPatientCaseMgt = getMenuLinks(\App\Models\User::MAIN_PATIENT_CASE)
    ?>
    <?php if($receptionistPatientCaseMgt): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('patients*','patient-cases*','case-handlers*','patient-admissions*') ? 'active' : ''); ?>"
               href="<?php echo e($receptionistPatientCaseMgt); ?>">
                <span class="menu-icon"><i class="fas fa-user-injured"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patients')); ?></span>
                <span class="d-none"><?php echo e(__('messages.cases')); ?></span>
                <span class="d-none"><?php echo e(__('messages.case_handlers')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_admissions')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if(isFeatureAllowToUse('pathology.category.index')): ?>
        <?php
        $receptionistPathologyMgt = getMenuLinks(\App\Models\User::MAIN_PATHOLOGY)
        ?>
        <?php if($receptionistPathologyMgt): ?>
            <div class="menu-item menu-accordion side-menus">
                <a class="menu-link menu-text-wrap <?php echo e(Request::is('pathology-categories*','pathology-tests*') ? 'active' : ''); ?>"
                   href="<?php echo e($receptionistPathologyMgt); ?>">
                    <span class="menu-icon"><i class="fa fa-flask"></i></span>
                    <span class="menu-title"><?php echo e(__('messages.pathologies')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.pathology_categories')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.pathology_tests')); ?></span>
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    
    <?php if(isFeatureAllowToUse('radiology.category.index')): ?>
        <?php
        $receptionistRadiology = getMenuLinks(\App\Models\User::MAIN_RADIOLOGY)
        ?>
        <?php if($receptionistRadiology): ?>
            <div class="menu-item menu-accordion side-menus">
                <a class="menu-link menu-text-wrap <?php echo e(Request::is('radiology-categories*','radiology-tests*') ? 'active' : ''); ?>"
                   href="<?php echo e($receptionistRadiology); ?>">
                    <span class="menu-icon"><i class="fa fa-x-ray"></i></span>
                    <span class="menu-title"><?php echo e(__('messages.radiologies')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.radiology_categories')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.radiology_tests')); ?></span>
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    
    <?php
    $receptionistServiceMgt = getMenuLinks(\App\Models\User::MAIN_SERVICE)
    ?>
    <?php if($receptionistServiceMgt): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('insurances*','packages*','services*','ambulances*','ambulance-calls*') ? 'active' : ''); ?>"
               href="<?php echo e($receptionistServiceMgt); ?>">
                <span class="menu-icon"><i class="fas fa-box"></i></span>
                <span class="menu-title"><?php echo e(__('messages.services')); ?></span>
                <span class="d-none"><?php echo e(__('messages.insurances')); ?></span>
                <span class="d-none"><?php echo e(__('messages.packages')); ?></span>
                <span class="d-none"><?php echo e(__('messages.services')); ?></span>
                <span class="d-none"><?php echo e(__('messages.ambulances')); ?></span>
                <span class="d-none"><?php echo e(__('messages.ambulance_calls')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if(isFeatureAllowToUse('sms.index')): ?>
        <?php
        $receptionistSmsMailMgt = getMenuLinks(\App\Models\User::MAIN_SMS_MAIL)
        ?>
        <?php if($receptionistSmsMailMgt): ?>
            <div class="menu-item side-menus">
                <a class="menu-link menu-text-wrap <?php echo e(Request::is('sms*','mail*') ? 'active' : ''); ?>"
                   href="<?php echo e($receptionistSmsMailMgt); ?>"
                   title="<?php echo e(__('SMS/Mail')); ?>">
        <span class="menu-icon">
            <i class="fas fa-bell"></i>
		</span>
                    <span class="menu-title"><?php echo e(__('SMS/Mail')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.sms.sms')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.mail')); ?></span>
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    
    
    
    
    
    
    
    
    
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('Pharmacist')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/doctor*') ? 'active' : ''); ?>"
               href="<?php echo e(route('doctor')); ?>">
                <span class="menu-icon"><i class="fa fa-user-md"></i></span>
                <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board*') ? 'active' : ''); ?>"
           href="<?php echo e(url('employee/notice-board')); ?>">
            <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
            <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Meetings',$modules)): ?>
    <?php if(isFeatureAllowToUse('live.meeting.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-meeting*') ? 'active' : ''); ?>"
               href="<?php echo e(route('live.meeting.index')); ?>">
                <span class="menu-icon"><i class="fa fa-file-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_meetings')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php
    $medicinePharmacistMgt = getMenuLinks(\App\Models\User::MAIN_MEDICINES)
    ?>
    <?php if($medicinePharmacistMgt): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('categories*','brands*','medicines*') ? 'active' : ''); ?>"
               href="<?php echo e($medicinePharmacistMgt); ?>">
                <span class="menu-icon"><i class="fas fa-capsules"></i></span>
                <span class="menu-title"><?php echo e(__('messages.medicines')); ?></span>
                <span class="d-none"><?php echo e(__('messages.medicine_categories')); ?></span>
                <span class="d-none"><?php echo e(__('messages.medicine_brands')); ?></span>
                <span class="d-none"><?php echo e(__('messages.medicines')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/payroll') ? 'active' : ''); ?>"
           href="<?php echo e(route('payroll')); ?>">
            <span class="menu-icon"><i class="fas fa-chart-pie"></i></span>
            <span class="menu-title"><?php echo e(__('messages.my_payrolls')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Pathology Tests',$modules)): ?>
    <?php if(isFeatureAllowToUse('pathology.test.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('pathology-tests*') ? 'active' : ''); ?>"
               href="<?php echo e(route('pathology.test.index')); ?>">
                <span class="menu-icon"><i class="fa fa-flask"></i></span>
                <span class="menu-title"><?php echo e(__('messages.pathologies')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Radiology Tests',$modules)): ?>
    <?php if(isFeatureAllowToUse('radiology.test.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('radiology-tests*') ? 'active' : ''); ?>"
               href="<?php echo e(route('radiology.test.index')); ?>">
                <span class="menu-icon"><i class="fa fa-x-ray"></i></span>
                <span class="menu-title"><?php echo e(__('messages.radiologies')); ?></span>
                <span class="d-none"><?php echo e(__('messages.radiology_tests')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'SMS',$modules)): ?>
    <?php if(isFeatureAllowToUse('sms.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('sms*') ? 'active' : ''); ?>"
               href="<?php echo e(route('sms.index')); ?>">
                <span class="menu-icon"><i class="fas fa fa-sms"></i></span>
                <span class="menu-title"><?php echo e(__('messages.sms.sms')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('Nurse')): ?>
    
    <?php $bedNurseMGT = getMenuLinks(\App\Models\User::MAIN_BED_MGT)
    ?>
    <?php if($bedNurseMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('bed-types*','beds*','bed-assigns*','bulk-beds') ? 'active' : ''); ?>"
               href="<?php echo e($bedNurseMGT); ?>">
                <span class="menu-icon"><i class="nav-icon fas fa-bed"></i></span>
                <span class="menu-title"><?php echo e(__('messages.bed_management')); ?></span>
                <span class="d-none"><?php echo e(__('messages.bed_types')); ?></span>
                <span class="d-none"><?php echo e(__('messages.beds')); ?></span>
                <span class="d-none"><?php echo e(__('messages.bed_assigns')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board*') ? 'active' : ''); ?>"
           href="<?php echo e(url('employee/notice-board')); ?>">
            <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
            <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Meetings',$modules)): ?>
    <?php if(isFeatureAllowToUse('live.meeting.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-meeting*') ? 'active' : ''); ?>"
               href="<?php echo e(route('live.meeting.index')); ?>">
                <span class="menu-icon"><i class="fa fa-file-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_meetings')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/payroll') ? 'active' : ''); ?>"
               href="<?php echo e(route('payroll')); ?>">
                <span class="menu-icon"><i class="fas fa-chart-pie"></i></span>
                <span class="menu-title"><?php echo e(__('messages.my_payrolls')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('Lab Technician')): ?>
    
    <?php if(isFeatureAllowToUse('blood-banks.index')): ?>
        <?php
        $bloodbankLabMGT = getMenuLinks(\App\Models\User::MAIN_BLOOD_BANK_MGT)
        ?>
        <?php if($bloodbankLabMGT): ?>
            <div class="menu-item menu-accordion side-menus">
                <a class="menu-link menu-text-wrap <?php echo e(Request::is('blood-banks*','blood-donors*','blood-donations*','blood-issues*') ? 'active' : ''); ?>"
                   href="<?php echo e($bloodbankLabMGT); ?>">
                    <span class="menu-icon"><i class="fas fa-tint"></i></span>
                    <span class="menu-title"><?php echo e(__('messages.blood_bank')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.blood_donors')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.blood_donations')); ?></span>
                    <span class="d-none"><?php echo e(__('messages.blood_issues')); ?></span>
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Doctors',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/doctor*') ? 'active' : ''); ?>"
           href="<?php echo e(route('doctor')); ?>">
            <span class="menu-icon"><i class="fa fa-user-md"></i></span>
            <span class="menu-title"><?php echo e(__('messages.doctors')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php
    $diagnosiLabMGT = getMenuLinks(\App\Models\User::MAIN_DIAGNOSIS)
    ?>
    <?php if($diagnosiLabMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('diagnosis-categories*','patient-diagnosis-test*') ? 'active' : ''); ?>"
               href="<?php echo e($diagnosiLabMGT); ?>">
                <span class="menu-icon"><i class="fas fa-diagnoses"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patient_diagnosis_test.diagnosis')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_category')); ?></span>
                <span class="d-none"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_test')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board*') ? 'active' : ''); ?>"
           href="<?php echo e(url('employee/notice-board')); ?>">
            <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
            <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Meetings',$modules)): ?>
    <?php if(isFeatureAllowToUse('live.meeting.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-meeting*') ? 'active' : ''); ?>"
               href="<?php echo e(route('live.meeting.index')); ?>">
                <span class="menu-icon"><i class="fa fa-file-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_meetings')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php
    $medicinelabMgt = getMenuLinks(\App\Models\User::MAIN_MEDICINES)
    ?>
    <?php if($medicinelabMgt): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('categories*','brands*','medicines*') ? 'active' : ''); ?>"
               href="<?php echo e($medicinelabMgt); ?>">
                <span class="menu-icon"><i class="fas fa-capsules"></i></span>
                <span class="menu-title"><?php echo e(__('messages.medicines')); ?></span>
                <span class="d-none"><?php echo e(__('messages.medicine_categories')); ?></span>
                <span class="d-none"><?php echo e(__('messages.medicine_brands')); ?></span>
                <span class="d-none"><?php echo e(__('messages.medicines')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/payroll') ? 'active' : ''); ?>"
           href="<?php echo e(route('payroll')); ?>">
            <span class="menu-icon"><i class="fas fa-chart-pie"></i></span>
            <span class="menu-title"><?php echo e(__('messages.my_payrolls')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Pathology Tests',$modules)): ?>
    <?php if(isFeatureAllowToUse('pathology.test.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('pathology-tests*') ? 'active' : ''); ?>"
               href="<?php echo e(route('pathology.test.index')); ?>">
                <span class="menu-icon"><i class="fa fa-flask"></i></span>
                <span class="menu-title"><?php echo e(__('messages.pathologies')); ?></span>
                <span class="d-none"><?php echo e(__('messages.pathology_tests')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Radiology Tests',$modules)): ?>
    <?php if(isFeatureAllowToUse('radiology.test.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('radiology-tests*') ? 'active' : ''); ?>"
               href="<?php echo e(route('radiology.test.index')); ?>">
                <span class="menu-icon"><i class="fa fa-x-ray"></i></span>
                <span class="menu-title"><?php echo e(__('messages.radiologies')); ?></span>
                <span class="d-none"><?php echo e(__('messages.radiology_tests')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('Accountant')): ?>
    
    <?php
    $billingAccountMGT = getMenuLinks(\App\Models\User::MAIN_ACCOUNT_MANAGER_MGT)
    ?>
    <?php if($billingAccountMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('accounts*','employee-payrolls*','invoices*','payments*','bills*') ? 'active' : ''); ?>"
               href="<?php echo e($billingAccountMGT); ?>">
                <span class="menu-icon"><i class="fab fa-adn"></i></span>
                <span class="menu-title"><?php echo e(__('messages.account_manager')); ?></span>
                <span class="d-none"><?php echo e(__('messages.accounts')); ?></span>
                <span class="d-none"><?php echo e(__('messages.employee_payrolls')); ?></span>
                <span class="d-none"><?php echo e(__('messages.invoices')); ?></span>
                <span class="d-none"><?php echo e(__('messages.payments')); ?></span>
                <span class="d-none"><?php echo e(__('messages.bills')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php
    $financeAccountantMGT = getMenuLinks(\App\Models\User::MAIN_FINANCE)
    ?>
    <?php if($financeAccountantMGT): ?>
        <div class="menu-item menu-accordion side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('incomes*','expenses*') ? 'active' : ''); ?>"
               href="<?php echo e($financeAccountantMGT); ?>">
                <span class="menu-icon"><i class="fas fa-money-bill"></i></span>
                <span class="menu-title"><?php echo e(__('messages.finance')); ?></span>
                <span class="d-none"><?php echo e(__('messages.incomes.incomes')); ?></span>
                <span class="d-none"><?php echo e(__('messages.expenses')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board*') ? 'active' : ''); ?>"
           href="<?php echo e(url('employee/notice-board')); ?>">
            <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
            <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Meetings',$modules)): ?>
    <?php if(isFeatureAllowToUse('live.meeting.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-meeting*') ? 'active' : ''); ?>"
               href="<?php echo e(route('live.meeting.index')); ?>">
                <span class="menu-icon"><i class="fa fa-file-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_meetings')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'My Payrolls',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/payroll') ? 'active' : ''); ?>"
               href="<?php echo e(route('payroll')); ?>">
                <span class="menu-icon"><i class="fas fa-chart-pie"></i></span>
                <span><?php echo e(__('messages.my_payrolls')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Services',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('services*') ? 'active' : ''); ?>"
               href="<?php echo e(route('services.index')); ?>">
                <span class="menu-icon"><i class="fas fa-box"></i></span>
                <span class="menu-title"><?php echo e(__('messages.services')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'SMS',$modules)): ?>
    <?php if(isFeatureAllowToUse('sms.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('sms*') ? 'active' : ''); ?>"
               href="<?php echo e(route('sms.index')); ?>">
                <span class="menu-icon"><i class="fas fa fa-sms"></i></span>
                <span class="menu-title"><?php echo e(__('messages.sms.sms')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('Patient')): ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Appointments',$modules)): ?>
    <?php if(isFeatureAllowToUse('appointments.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('appointments*') ? 'active' : ''); ?>"
               href="<?php echo e(route('appointments.index')); ?>">
                <span class="menu-icon"><i class="fas fa-calendar-check"></i></span>
                <span class="menu-title"><?php echo e(__('messages.appointments')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Bills',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/bills*') ? 'active' : ''); ?>"
           href="<?php echo e(url('employee/bills')); ?>">
            <span class="menu-icon"><i class="fa fa-rupee-sign"></i></span>
            <span class="menu-title"><?php echo e(__('messages.bills')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Diagnosis Tests',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/patient-diagnosis-test*') ? 'active' : ''); ?>"
               href="<?php echo e(route('patient-diagnosis-test')); ?>">
                <span class="menu-icon"><i class="fas fa-file-medical"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patient_diagnosis_test.diagnosis_test')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Documents',$modules)): ?>
    <?php if(isFeatureAllowToUse('documents.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('documents*') ? 'active' : ''); ?>"
               href="<?php echo e(route('documents.index')); ?>">
                <span class="menu-icon"><i class="fas fa-file"></i></span>
                <span class="menu-title"><?php echo e(__('messages.documents')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Notice Boards',$modules)): ?>
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/notice-board*') ? 'active' : ''); ?>"
           href="<?php echo e(url('employee/notice-board')); ?>">
            <span class="menu-icon"><i class="fas fa fa-cog"></i></span>
            <span class="menu-title"><?php echo e(__('messages.notice_boards')); ?></span>
            <span class="d-none"><?php echo e(__('messages.notice_boards')); ?></span>
        </a>
    </div>
    <?php endif; ?>

    
    <div class="menu-item side-menus">
        <a class="menu-link menu-text-wrap <?php echo e(Request::is('patient/my-ipds*','opds*','patient/my-opds*') ? 'active' : ''); ?>"
               href="<?php echo e(route('patient.ipd')); ?>"
               title="<?php echo e(__('messages.ipd_opd')); ?>">
        <span class="menu-icon">
            <i class="fas fa-notes-medical"></i>
        </span>
                <span class="menu-title"><?php echo e(__('messages.ipd_opd')); ?></span>
                <span class="d-none"><?php echo e(__('messages.ipd_patients')); ?></span>
                <span class="d-none"><?php echo e(__('messages.opd_patients')); ?></span>
            </a>
        </div>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Invoices',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/invoices*') ? 'active' : ''); ?>"
               href="<?php echo e(route('invoices')); ?>">
                <span class="menu-icon"><i class="fas fa-file-invoice"></i></span>
                <span class="menu-title"><?php echo e(__('messages.invoices')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Live Consultations',$modules)): ?>
    <?php if(isFeatureAllowToUse('live.consultation.index')): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('live-consultation*') ? 'active' : ''); ?>"
               href="<?php echo e(route('live.consultation.index')); ?>">
                <span class="menu-icon"><i class="fa fa-video"></i></span>
                <span class="menu-title"><?php echo e(__('messages.live_consultations')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Patient Cases',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('patient/my-cases*') ? 'active' : ''); ?>"
               href="<?php echo e(route('patients.cases')); ?>">
                <span class="menu-icon"><i class="fa fa-briefcase-medical"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patients_cases')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Patient Admissions',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('employee/patient-admissions*') ? 'active' : ''); ?>"
               href="<?php echo e(route('patient-admissions')); ?>">
                <span class="menu-icon"><i class="fas fa-history"></i></span>
                <span class="menu-title"><?php echo e(__('messages.patient_admissions')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Prescriptions',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('patient/my-prescriptions*') ? 'active' : ''); ?>"
               href="<?php echo e(route('prescriptions.list')); ?>">
                <span class="menu-icon"><i class="fas fa-prescription"></i></span>
                <span class="menu-title"><?php echo e(__('messages.prescriptions')); ?></span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('module', 'Vaccinated Patients',$modules)): ?>
        <div class="menu-item side-menus">
            <a class="menu-link menu-text-wrap <?php echo e(Request::is('patient/my-vaccinated*') ? 'active' : ''); ?>"
               href="<?php echo e(route('patient.vaccinated')); ?>">
                <span class="menu-icon"><i class="fas fa-head-side-mask"></i></span>
                <span class="menu-title"><?php echo e(__('messages.vaccinated_patients')); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>


<?php if(auth()->check() && auth()->user()->hasRole('Super Admin')): ?>

<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('super-admin/dashboard*') ? 'active' : ''); ?>"
       href="<?php echo e(route('super.admin.dashboard')); ?>">
        <span class="menu-icon">
            <i class="fas fa-chart-pie"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.dashboard.dashboard')); ?></span>
    </a>
</div>


<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('super-admin/hospitals*','super-admin/hospital*') ? 'active' : ''); ?>"
       href="<?php echo e(route('super.admin.hospitals.index')); ?>">
        <span class="menu-icon">
            <i class="fas fa-user-friends"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.hospitals')); ?></span>
    </a>
</div>


<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('super-admin/subscription-plans*','super-admin/transactions*') ? 'active' : ''); ?>"
       href="<?php echo e(route('super.admin.subscription.plans.index')); ?>">
        <span class="menu-icon">
            <i class="fas fa-rupee-sign"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.billing')); ?></span>
    </a>
</div>


<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('super-admin/subscribers*') ? 'active' : ''); ?>"
       href="<?php echo e(route('super.admin.subscribe.index')); ?>">
        <span class="menu-icon">
            <i class="fab fa-stripe-s"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.subscribe.subscribers')); ?></span>
    </a>
</div>


<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('super-admin/enquiries*') ? 'active' : ''); ?>"
       href="<?php echo e(route('super.admin.enquiry.index')); ?>">
        <span class="menu-icon">
            <i class="fab fa-elementor"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.enquiries')); ?></span>
    </a>
</div>


<div class="menu-item side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('super-admin/section-one*','super-admin/section-two*','super-admin/section-three*','super-admin/section-four*','super-admin/service-slider*','super-admin/admin-testimonial*','super-admin/faqs*','super-admin/section-five*','super-admin/about-us*') ? 'active' : ''); ?>"
       href="<?php echo e(route('super.admin.section.one')); ?>">
        <span class="menu-icon">
            <i class="fas fa fa-cog"></i>
		</span>
        <span class="menu-title"><?php echo e(__('messages.landing_cms.landing_cms')); ?></span>
    </a>
</div>


<div class="menu-item menu-accordion side-menus">
    <a class="menu-link menu-text-wrap <?php echo e(Request::is('super-admin/general-settings*','super-admin/footer-settings*') ? 'active' : ''); ?>"
       href="<?php echo e(route('super.admin.settings.edit')); ?>">
        <span class="menu-icon"><i class="fa fa-cogs"></i></span>
        <span class="menu-title"><?php echo e(__('messages.settings')); ?></span>
        <span class="d-none"><?php echo e(__('messages.general')); ?></span>
        <span class="d-none"><?php echo e(__('messages.sidebar_setting')); ?></span>
    </a>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/layouts/menu.blade.php ENDPATH**/ ?>