<div class="col-xl-4 my-4">
    <div class="price-table h-100 pricing-section">
        <div class="price-header">
            <h3 class="price-title"><?php echo e($subscriptionsPricingPlan->name); ?></h3>
            <div class="price-value">
                <h2>
                    <span><?php echo e(getSubscriptionPlanCurrencyIcon($subscriptionsPricingPlan->currency)); ?></span><?php echo e(number_format($subscriptionsPricingPlan->price)); ?>

                </h2>
                <span><?php echo e(\App\Models\SubscriptionPlan::PLAN_TYPE[$subscriptionsPricingPlan->frequency]); ?></span>
            </div>
        </div>
        <div class="price-list">
            <ul class="list-unstyled">
                <?php
                    $activeSubscription = getCurrentActiveSubscriptionPlan();
                ?>
                <?php if(getLoggedInUser() != null && count($subscriptionsPricingPlan->subscription) > 0): ?>
                    <?php if($activeSubscription !== null && $activeSubscription->trial_ends_at != null && $activeSubscription->subscription_plan_id == $subscriptionsPricingPlan->id): ?>
                        <li>
                            <h4><?php echo e(__('messages.subscription_plans.valid_until')); ?>

                                : <?php echo e($subscriptionsPricingPlan->trial_days); ?>

                            </h4>
                        </li>
                    <?php endif; ?>
                
                    <?php if($activeSubscription && isAuth() &&  $activeSubscription->subscriptionPlan->id == $subscriptionsPricingPlan->id): ?>
                        <li>
                            <h4>
                                <?php echo e(__('messages.subscription_plans.end_date')); ?>

                                :
                                <?php echo e(getParseDate($activeSubscription->ends_at)->format('d-m-Y')); ?>

                            </h4>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
        <?php if(count($subscriptionsPricingPlan->planFeatures) > 0): ?>
            <hr/>
            <div class="price-list">
                <ul class="list-unstyled d-inline-block text-start">
                    <?php $__currentLoopData = $subscriptionsPricingPlan->planFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planFeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><i class="fas fa-check-double"></i> <?php echo e($planFeature->feature->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php 
            $currentActiveSubscription = currentActiveSubscription();
        ?>

        <?php if($currentActiveSubscription && isAuth() && $subscriptionsPricingPlan->id == $currentActiveSubscription->subscription_plan_id && !$currentActiveSubscription->isExpired()): ?>
            <?php if($subscriptionsPricingPlan->price != 0): ?>
                <button type="button"
                        class="btn btn-success current-active-btn rounded-pill mx-auto d-block pricing-plan-button-active make-cursor-default"
                        data-id="<?php echo e($subscriptionsPricingPlan->id); ?>">
                    <span><?php echo e(__('messages.subscription_pricing_plans.currently_active')); ?></span></button>
            <?php else: ?>
                <button type="button"
                        class="btn btn-info rounded-pill mx-auto d-block renew-free-plan btn-fit-content make-cursor-default">
                    <span><?php echo e(__('messages.subscription_pricing_plans.renew_free_plan')); ?></span>
                </button>
            <?php endif; ?>
        <?php else: ?>
            <?php if($currentActiveSubscription && isAuth() && !$currentActiveSubscription->isExpired() && ($subscriptionsPricingPlan->price == 0 || $subscriptionsPricingPlan->price != 0)): ?>
                <?php if($subscriptionsPricingPlan->hasZeroPlan->count() == 0): ?>
                    <a href="<?php echo e($subscriptionsPricingPlan->price != 0 ? route('choose.payment.type', [$subscriptionsPricingPlan->id, 'landing', $screenFrom]) : 'javascript:void(0)'); ?>"
                       class="btn btn-primary border border-gray rounded-pill mx-auto d-block btn-fit-content <?php echo e($subscriptionsPricingPlan->price == 0 ? 'freePayment' : ''); ?>"
                       data-id="<?php echo e($subscriptionsPricingPlan->id); ?>"
                       data-plan-price="<?php echo e($subscriptionsPricingPlan->price); ?>">
                        <span><?php echo e(__('messages.subscription_pricing_plans.switch_plan')); ?></span></a>
                <?php else: ?>
                    <button type="button"
                            class="btn btn-info rounded-pill mx-auto d-block renew-free-plan btn-fit-content make-cursor-default">
                        <span><?php echo e(__('messages.subscription_pricing_plans.renew_free_plan')); ?></span>
                    </button>
                <?php endif; ?>
            <?php else: ?>
                <?php if($subscriptionsPricingPlan->hasZeroPlan->count() == 0): ?>
                    <a href="<?php echo e($subscriptionsPricingPlan->price != 0 ? route('choose.payment.type', [$subscriptionsPricingPlan->id, 'landing', $screenFrom]) : 'javascript:void(0)'); ?>"
                       class="btn btn-primary border border-gray rounded-pill mx-auto d-block btn-fit-content <?php echo e($subscriptionsPricingPlan->price == 0 ? 'freePayment' : ''); ?>"
                       data-id="<?php echo e($subscriptionsPricingPlan->id); ?>"
                       data-plan-price="<?php echo e($subscriptionsPricingPlan->price); ?>">
                        <span><?php echo e(__('messages.subscription_pricing_plans.choose_plan')); ?></span></a>
                <?php else: ?>
                    <button type="button"
                            class="btn btn-info rounded-pill mx-auto d-block renew-free-plan btn-fit-content make-cursor-default">
                        <span><?php echo e(__('messages.subscription_pricing_plans.renew_free_plan')); ?></span>
                    </button>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/landing/home/pricing_plan_section.blade.php ENDPATH**/ ?>