<table class="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100" id="doctorsDepartmentsTable">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <th><?php echo e(__('messages.appointment.doctor_category')); ?></th>
        <th><?php echo e(__('messages.common.action')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/doctor_categories/table.blade.php ENDPATH**/ ?>