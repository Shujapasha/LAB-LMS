<div class="footer py-4 d-flex flex-lg-column position-sticky bottom-0" id="kt_footer">
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-bold me-1">&copy <?php echo e(date('Y')); ?></span>
            <a href="<?php echo e(url('/')); ?>" class="text-gray-800 text-hover-primary"><?php echo e(config('app.name')); ?></a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/layouts/footer.blade.php ENDPATH**/ ?>