<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.dashboard.dashboard')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
    <link href="<?php echo e(mix('assets/css/dashboard.css')); ?>" rel="stylesheet" type="text/css"/>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/detail-header.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="post d-flex flex-column-fluid pt-15" id="kt_post">
        <div id="kt_content_container" class="container">
            <div class="row g-5 gx-xxl-8 justify-content-center">
                <?php if($modules['Invoices'] == true): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('invoices.index')); ?>"
                           class="card bg-primary hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-1">
                                <span class="rotate"><i
                                            class="fa fa-money-check fa-4x display-4 card-icon text-white"></i></span>
                                <div
                                    class="text-inverse-primary fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e(getCurrencySymbol()); ?> <?php echo e(formatCurrency($data['invoiceAmount'])); ?></div>
                                <div
                                    class="fw-bold text-inverse-primary fs-7"><?php echo e(__('messages.dashboard.total_invoices')); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($modules['Bills']): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('bills.index')); ?>" class="card bg-success hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-2">
                                <span class="rotate"><i
                                        class="fas fa-money-bill fa-4x display-4 card-icon text-white"></i></span>
                                <div
                                    class="text-inverse-success fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e(getCurrencySymbol()); ?> <?php echo e(formatCurrency($data['billAmount'])); ?></div>
                                <div
                                    class="fw-bold text-inverse-success fs-7"><?php echo e(__('messages.dashboard.total_bills')); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($modules['Payments'] == true): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('payments.index')); ?>"
                           class="card bg-info hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-3">
                                <span class="rotate"><i
                                        class="fas fa-money-bill-wave fa-4x display-4 card-icon text-white"></i></span>
                                <div
                                    class="text-inverse-info fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e(getCurrencySymbol()); ?> <?php echo e(formatCurrency($data['paymentAmount'])); ?></div>
                                <div
                                    class="fw-bold text-inverse-info fs-7"><?php echo e(__('messages.dashboard.total_payments')); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($modules['Advance Payments'] == true): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('advanced-payments.index')); ?>"
                           class="card bg-warning hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-4">
                                <span class="rotate"><i
                                        class="fas fa-money-bill-alt fa-4x display-4 card-icon text-white"></i></span>
                                <div
                                    class="text-inverse-warning fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e(getCurrencySymbol()); ?> <?php echo e(formatCurrency($data['advancePaymentAmount'])); ?></div>
                                <div
                                    class="fw-bold text-inverse-warning fs-7"><?php echo e(__('messages.dashboard.total_advance_payments')); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($modules['Doctors'] == true): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('doctors.index')); ?>"
                           class="card bg-secondary hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-5">
                                <span class="rotate"><i class="fas fa-user-md fa-4x display-4 card-icon text-dark"></i></span>
                                <div
                                    class="text-inverse-secondary fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e($data['doctors']); ?></div>
                                <div
                                    class="fw-bold text-inverse-secondary fs-7"><?php echo e(__('messages.dashboard.doctors')); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($modules['Patients'] == true): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('patients.index')); ?>"
                           class="card bg-danger hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-6">
                                <span class="rotate"><i
                                        class="fas fa-user fa-4x display-4 card-icon text-white"></i></span>
                                <div
                                    class="text-inverse-danger fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e($data['patients']); ?></div>
                                <div
                                    class="fw-bold text-inverse-danger fs-7"><?php echo e(__('messages.dashboard.patients')); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($modules['Nurses'] == true): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('nurses.index')); ?>" class="card bg-dark hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-7">
                                <span class="rotate"><i
                                        class="fas fa-user-nurse fa-4x display-4 card-icon text-white"></i></span>
                                <div
                                    class="text-inverse-dark fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e($data['nurses']); ?></div>
                                <div class="fw-bold text-inverse-dark fs-7"><?php echo e(__('messages.nurses')); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($modules['Beds'] == true): ?>
                    
                    <div class="col-xl-3 col-md-6">
                        <a href="<?php echo e(route('beds.index')); ?>" class="card bg-primary hoverable card-xl-stretch mb-xl-8">
                            <div class="card-body card-8">
                                <span class="rotate"><i
                                        class="fas fa-bed fa-4x display-4 card-icon text-white"></i></span>
                                <div
                                    class="text-inverse-primary fw-bolder card-count fs-2 mb-2 mt-5 amount-position"><?php echo e($data['availableBeds']); ?></div>
                                <div
                                    class="fw-bold text-inverse-primary fs-7"><?php echo e(__('messages.dashboard.available_beds')); ?></div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-xxl-7 col-xl-7">
                    <div class="card card-xxl-stretch mb-5 mb-xxl-8">
                        <div class="card-header border-0 pt-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bolder fs-3 mb-1"><?php echo e(__('messages.enquiries')); ?></span>
                            </h3>
                        </div>
                        <div class="card-body py-3">
                            <div class="table-responsive">
                                <?php if(count($data['enquiries']) > 0): ?>
                                    <table class="table table-row-dashed table-row-gray-200 align-middle gs-0 gy-4">
                                        <thead>
                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                            <th class="min-w-150px text-muted mt-1 fw-bold fs-7"><?php echo e(__('messages.enquiry.name')); ?></th>
                                            <th class="min-w-150px text-muted mt-1 fw-bold fs-7"><?php echo e(__('messages.enquiry.email')); ?></th>
                                            <th class="min-w-50px text-center text-muted mt-1 fw-bold fs-7"><?php echo e(__('messages.common.created_on')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody class="text-gray-600 fw-bold">
                                        <?php $__currentLoopData = $data['enquiries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(route('enquiry.show' , $enquiry->id)); ?>"
                                                       class="text-primary-800 mb-1 fs-6"><?php echo e($enquiry->full_name); ?></a>
                                                </td>
                                                <td class="text-start">
                                                        <span
                                                            class="text-muted fw-bold d-block"><?php echo e($enquiry->email); ?></span>
                                                </td>
                                                <td class="text-center text-muted fw-bold">
                                                        <span class="badge badge-light-info">
                                                        <?php echo e(date('jS M,Y', strtotime($enquiry->created_at))); ?>

                                                        </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <h2 class="text-center">No Enquiries yet..</h2>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-5 col-xl-5">
                    <div class="card card-xxl-stretch mb-5 mb-xxl-8">
                        <div class="card-header border-0 pt-5">
                            <h3 class="card-title align-items-start flex-column">
                                    <span
                                        class="card-label fw-bolder fs-3 mb-1"><?php echo e(__('messages.dashboard.notice_boards')); ?></span>
                            </h3>
                        </div>
                        <div class="card-body py-3">
                            <div class="table-responsive">
                                <?php if(count($data['enquiries']) > 0): ?>
                                <table class="table table-row-dashed table-row-gray-200 align-middle gs-0 gy-4">
                                    <thead>
                                    <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                        <th class="min-w-150px text-muted mt-1 fw-bold fs-7"><?php echo e(__('messages.dashboard.title')); ?></th>
                                        <th class="min-w-50px text-center text-muted mt-1 fw-bold fs-7"><?php echo e(__('messages.common.created_on')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-bold">
                                    <?php $__currentLoopData = $data['noticeBoards']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticeBoard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('notice-boards.show' , $noticeBoard->id)); ?>"
                                                   class="text-primary-800 mb-1 fs-6"><?php echo e(Str::limit($noticeBoard->title, 32,'...')); ?></a>
                                            </td>
                                            <td class="text-center text-muted fw-bold">
                                                    <span class="badge badge-light-info">
                                                        <?php echo e(date('jS M,Y', strtotime($noticeBoard->created_at))); ?>

                                                    </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                    <h2 class="text-center">No Notice Boards yet..</h2>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let incomeExpenseReportUrl = "<?php echo e(route('income-expense-report')); ?>";
        let currentCurrencyName = "<?php echo e(getCurrencySymbol()); ?>";
        let curencies = JSON.parse('<?php echo json_encode($data['currency'], 15, 512) ?>');
        let income_and_expense_reports = "<?php echo e(__('messages.dashboard.income_and_expense_reports')); ?>";
        let defaultAvatarImageUrl = "<?php echo e(asset('assets/img/avatar.png')); ?>";
    </script>
    
    <script src="<?php echo e(mix('assets/js/custom/input_price_format.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appointment\resources\views/dashboard/index.blade.php ENDPATH**/ ?>