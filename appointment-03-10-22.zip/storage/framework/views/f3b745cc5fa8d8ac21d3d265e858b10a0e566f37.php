<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(getAppName()); ?></title>
    <meta name="description" content="Hospital management system">
    <meta name="keyword" content="hospital,doctor,patient,fever,MD,MS,MBBS">
    <link rel="icon" href="<?php echo e(asset('web/img/hms-saas-favicon.ico')); ?>" type="image/png">
    <link rel="canonical" href="<?php echo e(route('landing.home')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('favicon.ico')); ?>" type="image/png">
    <link rel="icon" href="<?php echo e(asset('web/img/hms-saas-favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
    <link href="<?php echo e(asset('backend/css/vendor.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(mix('assets/css/custom.css')); ?>" rel="stylesheet" type="text/css"/>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<?php
$style = 'style=';
?>
<body id="kt_body"
      class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed toolbar-tablet-and-mobile-fixed aside-enabled aside-fixed"
<?php echo e($style); ?>"--kt-toolbar-height:55px;--kt-toolbar-height-tablet-and-mobile:55px">
<div class="d-flex flex-column flex-root">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Scripts -->
<script src="<?php echo e(asset('backend/js/vendor.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/3rd-party-custom.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<script>
    $(document).ready(function () {
        setTimeout(function () { $('.alert').fadeOut('slow'); }, 3000);
        $(document).on('submit', '.form-submit', function () {
            let buttonIndicator = document.querySelector('.indicator');
            buttonIndicator.setAttribute('data-kt-indicator', 'on');
        });
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/layouts/auth_app.blade.php ENDPATH**/ ?>