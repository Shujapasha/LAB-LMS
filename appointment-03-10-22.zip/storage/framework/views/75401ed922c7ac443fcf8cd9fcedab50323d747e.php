<!DOCTYPE html>
<html lang="en" <?php if(getLoggedInUser()->language == 'ar'): ?> direction="rtl" dir="rtl" style="direction: rtl" <?php endif; ?> >
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(getAppName()); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <?php 
        $settingValue = getSuperAdminSettingValue();
        $hospitalSettingValue = getSettingValue();
    ?>
    <meta name="google" content="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="icon"
          href="<?php echo e(!getLoggedInUser()->hasRole('Super Admin') ? asset($hospitalSettingValue['favicon']['value']) : asset($settingValue['favicon']['value'])); ?>"
          type="image/png">
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>

    <link href="<?php echo e(asset('backend/css/vendor.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('backend/css/datatables.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('backend/css/fonts.css')); ?>" rel="stylesheet" type="text/css"/>
    <?php echo $__env->yieldContent('page_css'); ?>
    <link href="<?php echo e(asset('backend/css/3rd-party.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('backend/css/3rd-party-custom.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(mix('assets/css/custom.css')); ?>" rel="stylesheet" type="text/css"/>

    <?php if(getLoggedInUser()->language =='ar'): ?>
        <link href="<?php echo e(asset('backend/css/style.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('backend/plugins/global/plugins.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('assets/css/style-rtl.css')); ?>" rel="stylesheet" type="text/css"/>
    <?php else: ?>
        <link href="<?php echo e(asset('backend/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css"/>
    <?php endif; ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<?php
$style = 'style=';
?>
<body id="kt_body"
      class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed"
<?php echo e($style); ?>"--kt-toolbar-height:55px;--kt-toolbar-height-tablet-and-mobile:55px"
data-new-gr-c-s-check-loaded="14.1025.0" data-gr-ext-installed="">
<div class="d-flex flex-column flex-root">
    <div class="page d-flex flex-row flex-column-fluid">
        <?php echo $__env->make('user_profile.edit_profile_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('user_profile.change_password_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="infy-loader" id="overlay-screen-lock">
            <?php echo $__env->make('loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="wrapper d-flex flex-column flex-row-fluid detail-kt-wrapper" id="kt_wrapper">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content d-flex flex-column flex-column-fluid content-padding-top" id="kt_content">
                <?php echo $__env->yieldContent('header_toolbar'); ?>
                <div class="post d-flex flex-column-fluid" id="kt_post">
                    <div id="kt_content_container" class="container">
                        <?php if(getLoggedInUser()->hasRole('Admin') && isSubscriptionExpired()['status']): ?>
                            <div class="alert alert-warning mt-5">
                                <div class="d-flex align-items-center">
                    <span class="svg-icon svg-icon-2hx svg-icon-warning me-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path opacity="0.3"
                                  d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z"
                                  fill="black"></path>
                            <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z"
                                  fill="black"></path>
                        </svg>
                    </span>
                                    <div>
                                        <span class="text-dark"><?php echo e(isSubscriptionExpired()['message']); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
<script src="<?php echo e(asset('backend/js/vendor.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/3rd-party-custom.js')); ?>"></script>
<script src="<?php echo e(mix('assets/js/custom/custom.js')); ?>"></script>
<script src="<?php echo e(mix('assets/js/custom/helpers.js')); ?>"></script>

<?php echo $__env->yieldContent('page_scripts'); ?>
<script>
    let defaultImage = '<?php echo e(asset('web_front/images/main-banner/banner-one/woman-doctor.png')); ?>';
    const defaultImageUrl = '';
    (function ($) {
        $.fn.button = function (action) {
            if (action === 'loading' && this.data('loading-text')) {
                this.data('original-text', this.html()).html(this.data('loading-text')).prop('disabled', true);
            }
            if (action === 'reset' && this.data('original-text')) {
                this.html(this.data('original-text')).prop('disabled', false);
            }
        };
        $('#overlay-screen-lock').hide();
    }(jQuery));
    $(document).ready(function () {
        $('.alert').delay(5000).slideUp(300);
    });

    $(document).ready(function () {
        $('#kt_aside').removeClass('aside-hoverable');
    });

    $('.alert').delay(5000).slideUp(300, function () {
        $('.alert').attr('style', 'display:none');
    });

</script>
<?php echo $__env->yieldContent('scripts'); ?>
<script>
    let profileUrl = "<?php echo e(url('profile')); ?>";
    let profileUpdateUrl = "<?php echo e(url('profile-update')); ?>";
    let changePasswordUrl = "<?php echo e(url('change-password')); ?>";
    let loggedInUserId = "<?php echo e(getLoggedInUserId()); ?>";
    let updateLanguageURL = "<?php echo e(url('update-language')); ?>";
    let currentCurrency = "<?php echo e(getCurrencySymbol()); ?>";
    let pdfDocumentImageUrl = "<?php echo e(url('assets/img/pdf.png')); ?>";
    let docxDocumentImageUrl = "<?php echo e(url('assets/img/doc.png')); ?>";
    let ajaxCallIsRunning = false;
    let userCurrentLanguage = "<?php echo e(getLoggedInUser()->language); ?>";
</script>
<script src="<?php echo e(mix('assets/js/user_profile/user_profile.js')); ?>"></script>
<script src="<?php echo e(mix('assets/js/sidebar_menu_search/sidebar_menu_search.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/layouts/app.blade.php ENDPATH**/ ?>