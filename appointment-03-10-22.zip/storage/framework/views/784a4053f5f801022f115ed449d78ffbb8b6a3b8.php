<table class="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer table-responsive-sm w-100"
       id="accountsTbl">
    <thead>
    <tr class="fw-bold fs-6 text-muted">
        <th><?php echo e(__('messages.account.account')); ?></th>
        <th><?php echo e(__('messages.account.type')); ?></th>
        <th><?php echo e(__('messages.common.status')); ?></th>
        <th><?php echo e(__('messages.common.action')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/accounts/table.blade.php ENDPATH**/ ?>