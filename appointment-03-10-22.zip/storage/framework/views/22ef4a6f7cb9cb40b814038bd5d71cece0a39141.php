<section id="pricing">
    <div class="container">
        <?php echo $__env->make('landing.home.pricing_plan_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row align-items-center">
            <div class="col-lg-12 col-md-12">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="monthContent" role="tabpanel"
                         aria-labelledby="month-tab">
                        <div class="row justify-content-center">
                            <?php $__empty_1 = true; $__currentLoopData = $subscriptionPricingMonthPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriptionsPricingPlan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('landing.home.pricing_plan_section', ['screenFrom' => $screenFrom], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-lg-4 col-md-6">
                                    <div class="card text-center empty_featured_card">
                                        <div class="card-body d-flex align-items-center justify-content-center">
                                            <div>
                                                <div class="empty-featured-portfolio">
                                                    <i class="fas fa-question"></i>
                                                </div>
                                                <h3 class="card-title mt-3">
                                                    <?php echo e(__('messages.subscription_month_plan_not_found')); ?>

                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="yearContent" role="tabpanel"
                         aria-labelledby="year-tab">
                        <div class="row justify-content-center">
                            <?php $__empty_1 = true; $__currentLoopData = $subscriptionPricingYearPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriptionsPricingPlan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('landing.home.pricing_plan_section', ['screenFrom' => $screenFrom], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-lg-4 col-md-6">
                                    <div class="card text-center empty_featured_card">
                                        <div class="card-body d-flex align-items-center justify-content-center">
                                            <div>
                                                <div class="empty-featured-portfolio">
                                                    <i class="fas fa-question"></i>
                                                </div>
                                                <h3 class="card-title mt-3">
                                                    <?php echo e(__('messages.subscription_year_plan_not_found')); ?>

                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/landing/landing_pricing_plan/index.blade.php ENDPATH**/ ?>