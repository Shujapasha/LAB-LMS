<?php $__env->startSection('title'); ?>
    Patients Cases
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sub-header.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header border-0 pt-6">
            <?php echo $__env->make('layouts.search-component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-body pt-0 fs-6 py-8 px-8  px-lg-10 text-gray-700">
            <?php echo $__env->make('patients_cases_list.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let patientCasesUrl = "<?php echo e(url('patient/my-cases')); ?>";
        let patientCaseShowUrl = "<?php echo e(url('patient/my-cases')); ?>";
        let patientUrl = "<?php echo e(url('patients')); ?>";
    </script>
    <script src="<?php echo e(mix('assets/js/custom/input_price_format.js')); ?>"></script>
    <script src="<?php echo e(mix('assets/js/patient_cases_list/patient_cases_list.js')); ?>"></script>
    <script src="<?php echo e(mix('assets/js/custom/custom-datatable.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appointment\resources\views/patients_cases_list/index.blade.php ENDPATH**/ ?>