<table class="table table-responsive-sm align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100"
       id="prescriptionsTable">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <th><?php echo e(__('messages.prescription.patient')); ?></th>
        <th><?php echo e(__('messages.patient_admission.doctor')); ?></th>
        <th><?php echo e(__('messages.prescription.medical_history')); ?></th>
        <th><?php echo e(__('messages.prescription.current_medication')); ?></th>
        <th><?php echo e(__('messages.prescription.health_insurance')); ?></th>
        <th><?php echo e(__('messages.prescription.low_income')); ?></th>
        <th><?php echo e(__('messages.prescription.reference')); ?></th>
        <th><?php echo e(__('messages.common.status')); ?></th>
        <th><?php echo e(__('messages.common.action')); ?></th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/patients_prescription_list/table.blade.php ENDPATH**/ ?>