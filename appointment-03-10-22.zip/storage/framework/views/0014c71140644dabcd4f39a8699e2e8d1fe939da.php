<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!--begin::Authentication - Sign-in -->
    <?php
        $style = 'style=background-image:url('.asset('assets/img/progress-hd.png').')';
        $settingValue = getSuperAdminSettingValue();
    ?>
    <div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" <?php echo e($style); ?>>
        <div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">
            <a href="<?php echo e(route('landing.home')); ?>" class="mb-12">
                <img alt="Logo" src="<?php echo e(asset($settingValue['app_logo']['value'])); ?>" class="h-45px"/>
            </a>
            <div class="w-lg-500px bg-white rounded shadow-sm p-10 p-lg-15 mx-auto">
                <form method="post" class="form w-100 form-submit" action="<?php echo e(url('/login')); ?>" id="kt_sign_in_form">
                    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <input type="hidden" name="route_name"
                           value="<?php echo e(app('router')->getRoutes()->match(app('request')->create(url()->previous()))->getName()); ?>">
                    <div class="text-center mb-10">
                        <h1 class="text-dark mb-3">Sign In</h1>
                        <div class="text-gray-400 fw-bold fs-4">New Here?
                            <a href="<?php echo e(route('register')); ?>" class="link-primary fw-bolder">Create an Account</a>
                        </div>
                    </div>
                    <div class="fv-row mb-10">
                        <label class="form-label fs-6 fw-bolder text-dark">
                            Email: <span class="text-danger">*</span>
                        </label>
                        <input type="email" class="form-control form-control-lg form-control-solid" name="email"
                               placeholder="Enter Email"
                               value="<?php echo e((Cookie::get('email') !== null) ? Cookie::get('email') : old('email')); ?>"
                               required>
                    </div>
                    <div class="fv-row mb-10">
                        <div class="d-flex flex-stack mb-2">
                            <label class="form-label fw-bolder text-dark fs-6 mb-0">
                                Password: <span class="text-danger">*</span>
                            </label>
                            <a href="<?php echo e(url('/password/reset')); ?>" class="link-primary fs-6 fw-bolder">Forgot Password
                                ?</a>
                        </div>
                        <input type="password"
                               class="form-control form-control-lg form-control-solid" name="password"
                               placeholder="Enter Password"
                               value="<?php echo e((Cookie::get('password') !== null) ? Cookie::get('password') : null); ?>"
                               required>
                    </div>
                    <div class="fv-row mb-10">
                        <label class="form-check form-check-custom form-check-solid form-check-inline"
                               for="remember_me">
                            <input class="form-check-input" id="remember_me" type="checkbox" name="remember">
                            <span class="form-check-label fw-bold text-gray-700 fs-6">Remember me</span>
                        </label>
                    </div>
                    <div class="text-center">
                        <button type="submit" id="kt_sign_in_submit"
                                class="btn btn-lg btn-primary w-100 mb-5 indicator">
                            <span class="indicator-label">Login</span>
                            <span class="indicator-progress">Please wait...
									<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--end::Authentication - Sign-in -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appointment\resources\views/auth/login.blade.php ENDPATH**/ ?>