
<div class="row gx-10 mb-5">
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('first_name', __('messages.user.first_name').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?><span class="required"></span>
            <?php echo e(Form::text('first_name', null, ['class' => 'form-control form-control-solid', 'required', 'id' => 'firstName','tabindex' => '1'])); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('last_name', __('messages.user.last_name').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?><span class="required"></span>
            <?php echo e(Form::text('last_name', null, ['class' => 'form-control form-control-solid', 'required', 'tabindex' => '2'])); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('email', __('messages.user.email').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?><span class="required"></span>
            <?php echo e(Form::email('email', null, ['class' => 'form-control form-control-solid', 'required', 'tabindex' => '3'])); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('dob', __('messages.user.dob').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('dob', null, ['class' => 'form-control form-control-solid', 'id' => 'birthDate', 'autocomplete' => 'off', 'tabindex' => '4'])); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mobile-overlapping  mb-5">
            <?php echo e(Form::label('phone', __('messages.user.phone').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?><span class="required"></span><br>
            <?php echo e(Form::tel('phone', null, ['class' => 'form-control form-control-solid', 'id' => 'phoneNumber', 'required', 'onkeyup' => 'if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,"")', 'tabindex' => '5'])); ?>

            <?php echo e(Form::hidden('prefix_code',null,['id'=>'prefix_code'])); ?>

            <span id="valid-msg" class="hide">✓ &nbsp; Valid</span>
            <span id="error-msg" class="hide"></span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('gender', __('messages.user.gender').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?><span
                class="required"></span> &nbsp;<br>
            <span class="form-check form-check-custom form-check-solid is-valid form-check-sm">
                <label class="form-label fs-6 fw-bolder text-gray-700 m-3"><?php echo e(__('messages.user.male')); ?></label>&nbsp;&nbsp;
                <?php echo e(Form::radio('gender', '0', true, ['class' => 'form-check-input', 'tabindex' => '6'])); ?> &nbsp;
                <label class="form-label fs-6 fw-bolder text-gray-700 m-3"><?php echo e(__('messages.user.female')); ?></label>
                <?php echo e(Form::radio('gender', '1', false, ['class' => 'form-check-input', 'tabindex' => '7'])); ?>

            </span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('status', __('messages.common.status').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <div class="form-check form-switch form-check-custom form-check-solid">
                <input class="form-check-input w-35px h-20px is-active" name="status" type="checkbox" value="1"
                       tabindex="8" checked>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('blood_group', __('messages.user.blood_group').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::select('blood_group', $bloodGroup, null, ['class' => 'form-select form-select-solid fw-bold', 'id' => 'bloodGroup', 'placeholder' => 'Select Blood Group', 'data-control' => 'select2', 'tabindex' => "9"])); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('patient_referral', __('messages.user.patient_referral').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::select('patient_referral', $doctorReferrals, null, ['class' => 'form-select form-select-solid fw-bold', 'id' => 'bloodGroup', 'placeholder' => 'Select Referral', 'data-control' => 'select2', 'tabindex' => "9"])); ?>

        </div>
    </div>
    <!-- <div class="col-md-3">
        <div class="form-group mb-5" data-kt-password-meter="true">
            <?php echo e(Form::label('password', __('messages.user.password').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <span class="required"></span>
            <?php echo e(Form::password('password', ['class' => 'form-control form-control-solid','required','min' => '6','max' => '10', 'tabindex' => '10'])); ?>

            <div class="d-flex align-items-center my-3" data-kt-password-meter-control="highlight">
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px"></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5" data-kt-password-meter="true">
            <?php echo e(Form::label('password_confirmation', __('messages.user.password_confirmation').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <span class="required"></span>
            <?php echo e(Form::password('password_confirmation', ['class' => 'form-control form-control-solid','required','min' => '6','max' => '10', 'tabindex' => '11'])); ?>

            <div class="d-flex align-items-center my-3" data-kt-password-meter-control="highlight">
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px"></div>
            </div>
        </div>
    </div> -->
    <div class="form-group col-md-4 mb-5">
        <div class="row2">
            <?php echo e(Form::label('image', __('messages.profile.profile').':', ['class' => 'fs-5 fw-bold mb-2 d-block'])); ?>

            <div class="image-input image-input-outline" data-kt-image-input="true">
                <?php
                $style = 'style=';
                $background = 'background-image:';
                ?>
                <div class="image-input-wrapper w-125px h-125px bgi-position-center" id="previewImage"
                <?php echo e($style); ?>"<?php echo e($background); ?> url(<?php echo e(asset('assets/img/avatar.png')); ?>)">
            </div>

            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow"
                   data-kt-image-input-action="change"
                   data-bs-toggle="tooltip"
                   data-bs-dismiss="click"
                   title="Change profile">
                <i class="bi bi-pencil-fill fs-7"></i>

                <input type="file" name="image" id="profileImage" accept=".png, .jpg, .jpeg, .gif"/>
                <input type="hidden" name="avatar_remove"/>
                </label>

                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow"
                      data-kt-image-input-action="cancel"
                      data-bs-toggle="tooltip"
                      data-bs-dismiss="click"
                      title="Cancel profile">
                        <i class="bi bi-x fs-2"></i>
                </span>
                <span
                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow remove-image"
                    data-kt-image-input-action="remove"
                    data-bs-toggle="tooltip"
                    data-bs-dismiss="click"
                    title="Remove profile">
                        <i class="bi bi-x fs-2"></i>
                </span>
            </div>
        </div>
    </div>
</div>
<hr>
<div class="row mt-3 mb-5">
    <div class="col-md-12 mb-3">
        <h5>Test</h5>
    </div>
    <!-- <div class="col-md-6">
        <div class="form-group mb-5">
             <?php echo e(Form::label('patient_test', __('messages.user.patient_test').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::select('patient_test', $doctorRadiologyTest, null, ['class' => 'form-select form-select-solid fw-bold', 'id' => 'patientTest', 'placeholder' => 'Select Test', 'data-control' => 'select2', 'tabindex' => "9"])); ?>

        </div>
    </div> -->
</div>
<div class="row mt-3 mb-5">
    <div class="col-md-3">
        <?php echo e(Form::select('patient_test[]', $doctorRadiologyTest, null, ['class' => 'form-select form-select-solid fw-bold', 'id' => 'patientTest', 'placeholder' => 'Select Test', 'data-control' => 'select2', 'tabindex' => "9"])); ?>

    </div>
    <div class="col-md-3">
        <?php echo e(Form::text('nameTest[]', null, ['class' => 'form-control form-control-solid nameTest', 'id' => 'nameTest', 'placeholder' => 'Name', 'autocomplete' => 'off', 'tabindex' => '4'])); ?>

    </div>
    <div class="col-md-3">
        <?php echo e(Form::text('Fee[]', null, ['class' => 'form-control form-control-solid fee', 'id' => 'Fee', 'placeholder' => 'Fee', 'autocomplete' => 'off', 'tabindex' => '4'])); ?>

    </div>
     <div class="col-md-3">
       <?php echo e(Form::select('discount_by[]', [ 0 => 'Gilani Altrasound', 1 => 'Referral'], null, ['class' => 'form-select form-select-solid fw-bold discountBy', 'id' => 'discountBy', 'placeholder' => 'Discount by', 'data-control' => 'select2', 'tabindex' => "9"])); ?>

    </div>
    <div class="col-md-3 mt-3">
        <?php echo e(Form::text('Discount[]', null, ['class' => 'form-control form-control-solid discount', 'placeholder' => 'Discount', 'autocomplete' => 'off', 'tabindex' => '4'])); ?>

    </div>
    <div class="col-md-3 mt-3">
        <?php echo e(Form::text('NetAmount[]', null, ['class' => 'form-control form-control-solid netAmount', 'id' => 'NetAmount', 'placeholder' => 'NetAmount', 'autocomplete' => 'off', 'tabindex' => '4'])); ?>

    </div>
</div>
<div id="newRow">
    
</div>
<div class="row mt-3 mb-5">
    <div class="col-md-12">
         <button id="addRow" type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Add More</button>
    </div>
</div>

<hr>
<div class="row mt-3 mb-5">
    <div class="col-md-12 mb-3">
        <h5><?php echo e(__('messages.user.address_details')); ?></h5>
    </div>
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('address1', __('messages.user.address1').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('address1', null, ['class' => 'form-control form-control-solid'])); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mb-5">
            <?php echo e(Form::label('address2', __('messages.user.address2').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('address2', null, ['class' => 'form-control form-control-solid'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('city', __('messages.user.city').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('city', null, ['class' => 'form-control form-control-solid'])); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group mb-5">
            <?php echo e(Form::label('zip', __('messages.user.zip').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

            <?php echo e(Form::text('zip', null, ['class' => 'form-control form-control-solid', 'maxlength' => '6','minlength' => '6'])); ?>

        </div>
    </div>
</div>
<hr>
<div class="row mt-3 mb-5">
    <div class="col-md-12 mb-3">
        <h5><?php echo e(__('messages.setting.social_details')); ?></h5>
    </div>

    <!-- Facebook URL Field -->
    <div class="form-group col-sm-6 mb-5">
        <?php echo e(Form::label('facebook_url', __('messages.facebook_url').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

        <?php echo e(Form::text('facebook_url', null, ['class' => 'form-control form-control-solid','id'=>'facebookUrl', 'onkeypress' => 'return avoidSpace(event);'])); ?>

    </div>

    <!-- Twitter URL Field -->
    <div class="form-group col-sm-6 mb-5">
        <?php echo e(Form::label('twitter_url', __('messages.twitter_url').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

        <?php echo e(Form::text('twitter_url', null, ['class' => 'form-control form-control-solid','id'=>'twitterUrl', 'onkeypress' => 'return avoidSpace(event);'])); ?>

    </div>

    <!-- Instagram URL Field -->
    <div class="form-group col-sm-6 mb-5">
        <?php echo e(Form::label('instagram_url', __('messages.instagram_url').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

        <?php echo e(Form::text('instagram_url', null, ['class' => 'form-control form-control-solid', 'id'=>'instagramUrl', 'onkeypress' => 'return avoidSpace(event);'])); ?>

    </div>

    <!-- LinkedIn URL Field -->
    <div class="form-group col-sm-6 mb-5">
        <?php echo e(Form::label('linkedIn_url', __('messages.linkedIn_url').':', ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

        <?php echo e(Form::text('linkedIn_url', null, ['class' => 'form-control form-control-solid','id'=>'linkedInUrl', 'onkeypress' => 'return avoidSpace(event);'])); ?>

    </div>

</div>
<div class="d-flex">
    <?php echo e(Form::submit(__('messages.common.save'), ['class' => 'btn btn-primary me-2','id' => 'btnSave'])); ?>

    <a href="<?php echo e(route('patients.index')); ?>"
       class="btn btn-light btn-active-light-primary me-2"><?php echo __('messages.common.cancel'); ?></a>
</div>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/patients/fields.blade.php ENDPATH**/ ?>