<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="title" content="<?php echo e(config('app.name')); ?>">

    <meta name="keywords" content="<?php echo e(getCompanyName()); ?>"/>

    <meta name="description" content="<?php echo e(getAppName()); ?>"/>
    <meta name="author" content="<?php echo e(getCompanyName()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>404 Not Found | <?php echo e(config('app.name')); ?></title>

    <link href="<?php echo e(asset('backend/css/vendor.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('backend/css/datatables.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('backend/css/fonts.css')); ?>" rel="stylesheet" type="text/css"/>
    <?php echo $__env->yieldContent('page_css'); ?>
    <link href="<?php echo e(asset('backend/css/3rd-party.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('backend/css/3rd-party-custom.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(mix('assets/css/custom.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(mix('assets/css/custom.css')); ?>" rel="stylesheet" type="text/css"/>
</head>
<body class="d-flex ">
<div class="d-flex flex-column flex-root">
    <div class="d-flex flex-column flex-center flex-column-fluid p-10">
        <img src="<?php echo e(asset('web/img/404.png')); ?>" class="mw-100 mb-10 h-lg-450px">
        <h1 class="fw-bold mb-10">Opps! Something's missing...</h1>
        <a class="btn btn-primary fw-bolder mt-3" href="<?php echo e(route('landing.home')); ?>">Back to Home Page</a>
    </div>
</div>
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appointment\resources\views/errors/404.blade.php ENDPATH**/ ?>