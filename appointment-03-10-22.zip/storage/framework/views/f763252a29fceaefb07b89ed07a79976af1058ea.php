<?php echo e(strip_tags($header)); ?>


<?php echo e(strip_tags($slot)); ?>

<?php if(isset($subcopy)): ?>

<?php echo e(strip_tags($subcopy)); ?>

<?php endif; ?>

<?php echo e(strip_tags($footer)); ?>

<?php /**PATH C:\xampp\htdocs\appointment\resources\views/vendor/mail/text/layout.blade.php ENDPATH**/ ?>