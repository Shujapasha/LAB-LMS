<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.appointment.appointment_calendar')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
    <link href="<?php echo e(asset('assets/css/plugins/fullcalendar.bundle.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_toolbar'); ?>
    <div class="toolbar" id="kt_toolbar">
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                 data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                 class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                <h1 class="d-flex align-items-center text-dark fw-bolder fs-3 my-1"><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="d-flex align-items-center py-1">
                <a href="<?php echo e(route('appointments.index')); ?>"
                   class="btn btn-sm btn-primary"><?php echo e(__('messages.appointment.appointment_list')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column flex-lg-row">
        <div class="flex-lg-row-fluid mb-10 mb-lg-0 me-lg-7 me-xl-10">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="card">
                <div class="card-body p-12">
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
    </div>

    
    <div id="appointmentDetailModal" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h2><?php echo e(__('messages.appointment.appointment_details')); ?></h2>
                    <button type="button" aria-label="Close" class="btn btn-sm btn-icon btn-active-color-primary"
                            data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                             version="1.1">
							<g transform="translate(12.000000, 12.000000) rotate(-45.000000) translate(-12.000000, -12.000000) translate(4.000000, 4.000000)"
                               fill="#000000">
								<rect fill="#000000" x="0" y="7" width="16" height="2" rx="1"/>
								<rect fill="#000000" opacity="0.5"
                                      transform="translate(8.000000, 8.000000) rotate(-270.000000) translate(-8.000000, -8.000000)"
                                      x="0" y="7" width="16" height="2" rx="1"/>
							</g>
						</svg>
					</span>
                    </button>
                </div>
                <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                    <div class="row">
                        <div class="form-group col-sm-12 mb-5">
                            <?php echo e(Form::label('patient_name', __('messages.case.patient').(':'), ['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

                            <p id="patientName"></p>
                        </div>
                        <div class="form-group col-sm-12 mb-5">
                            <?php echo e(Form::label('department_name', __('messages.appointment.doctor_department').(':'),['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

                            <p id="departmentName"></p>
                        </div>
                        <div class="form-group col-sm-12 mb-5">
                            <?php echo e(Form::label('doctor_name', __('messages.case.doctor').(':'),['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

                            <p id="doctorName"></p>
                        </div>
                        <div class="form-group col-sm-12 mb-5">
                            <?php echo e(Form::label('opd_date', __('messages.appointment.date').(':'),['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

                            <br>
                            <p id="opdDate"></p>
                        </div>
                        <div class="form-group col-sm-12 mb-5">
                            <?php echo e(Form::label('problem', __('messages.common.status').(':'),['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

                            <p id="is_completed"></p>
                        </div>
                        <div class="form-group col-sm-12 mb-5">
                            <?php echo e(Form::label('problem', __('messages.appointment.description').(':'),['class' => 'form-label fs-6 fw-bolder text-gray-700 mb-3'])); ?>

                            <p id="problem"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('appointment_calendars.add_appointment_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('appointments.templates.appointment_slot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/fullcalendar.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let todayText = '<?php echo e(__('messages.appointment.today')); ?>';
        let monthText = '<?php echo e(__('messages.appointment.month')); ?>';
        let weekText = '<?php echo e(__('messages.appointment.week')); ?>';
        let dayText = '<?php echo e(__('messages.appointment.day')); ?>';
        let doctorScheduleList = "<?php echo e(url('doctor-schedule-list')); ?>";
        let calenderAppointmentSaveUrl = "<?php echo e(route('appointments.store')); ?>";
        let calenderIndexPage = "<?php echo e(route('appointment-calendars.index')); ?>";
        let getBookingSlot = "<?php echo e(route('get.booking.slot')); ?>";
        let userRole = "<?php echo e(Auth::user()->hasRole('Doctor')); ?>";
        let isCreate = true;
        let isDoctor = <?php echo e((Auth::user()->hasRole('Doctor'))? 1 :0); ?>;
    </script>
    <script src="<?php echo e(mix('assets/js/appointment_calendar/appointment_calendar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appointment\resources\views/appointment_calendars/index.blade.php ENDPATH**/ ?>